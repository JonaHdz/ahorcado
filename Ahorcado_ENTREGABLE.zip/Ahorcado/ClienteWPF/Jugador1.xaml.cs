﻿using ServiceReference1;
using System;
using System.Windows;
using System.Windows.Media;
using System.Windows.Threading;

namespace ClienteWPF
{
    /// <summary>
    /// Lógica de interacción para Jugador1.xaml
    /// </summary>
    public partial class Jugador1 : Window
    {

        private Partida infoPartida;
        private DispatcherTimer temporizador;
        private EsperaTurnoJugador ventanaEsperaTurno;
        private ServicioJuegoClient servicio;
        private MensajePartidaEjecucion mensajePartidaEjecucion = new MensajePartidaEjecucion();
        private int[] camposUsados = new int[9];

        public Jugador1()
        {
            InitializeComponent();
            servicio = new ServicioJuegoClient();
            configurarCamposUsados();
            //temporizador = new DispatcherTimer();//para el temporizador
            temporizador = new DispatcherTimer();
            temporizador.Interval = new TimeSpan(0, 0, 0, 3);//cada  segundo
            temporizador.Tick += (a, b) =>
            {
                VerificarTurnoJugador();
            };
            VisibilidadBotones(false);
            temporizador.Start();
        }

        public async void VerificarTurnoJugador()////////////////
        {
            if (servicio != null)
            {
                // if (mensajePartidaEjecucion !=null&& mensajePartidaEjecucion.partidaEjecucion!=null && mensajePartidaEjecucion.partidaEjecucion.TurnoJugador!=null && mensajePartidaEjecucion.partidaEjecucion.TurnoJugador == turnoJugador)//turno del jugador uno para jugar

                mensajePartidaEjecucion = await servicio.recuperarPartidaEjecucionAsync(infoPartida.IdPartida);//aveces msarca error de instancia tras un timepo en ejecucion sin que yo haga nada
                if (mensajePartidaEjecucion != null && mensajePartidaEjecucion.partidaEjecucion != null && mensajePartidaEjecucion.partidaEjecucion.TurnoJugador != null && mensajePartidaEjecucion.partidaEjecucion.TurnoJugador == 1)//turno del jugador uno para jugar
                {//podria agregar una comprobacion de que no sea null antes dea condicion de arriba
 
                    AnalizarRespuesta();
                    
                }

            }

        }



        private void configurarCamposUsados()
        {
            camposUsados[0] = 0;
            camposUsados[1] = 0;
            camposUsados[2] = 0;
            camposUsados[3] = 0;
            camposUsados[4] = 0;
            camposUsados[5] = 0;
            camposUsados[6] = 0;
            camposUsados[7] = 0;
            camposUsados[8] = 0;

        }


        public void CargarDatosPartida(Partida infoPartida)
        {
            this.infoPartida = infoPartida;
        }

        public void AnalizarRespuesta()
        {                                
            CargarJugadaJugadorUno();
        }

        private async void CargarJugadaJugadorUno()
        {
            if (servicio != null)
            {
                mensajePartidaEjecucion = new MensajePartidaEjecucion();
                mensajePartidaEjecucion = await servicio.recuperarPartidaEjecucionAsync(infoPartida.IdPartida);//para recuperar letra

                if (mensajePartidaEjecucion.partidaEjecucion == null || mensajePartidaEjecucion == null || mensajePartidaEjecucion.Error ||mensajePartidaEjecucion.partidaEjecucion.LetraIngresada==null)//se lo acabo de agregar para evitar el null
                {
                    MessageBox.Show("no se pudo recuperar la informacion de la jugada para cargarla en la pantalla jugador 1");
                    CargarJugadaJugadorUno();
                }    
                else
                {
                    if (mensajePartidaEjecucion.partidaEjecucion.EstadoPartidaEjecucion.Equals("cancelada"))
                    {
                        temporizador.Stop();
                        MessageBox.Show("La partida ha sido cancelada por el otro jugador");
                        CargarPantallaSalas();
                    }
                    else
                    {
                        tbLetra.Text = mensajePartidaEjecucion.partidaEjecucion.LetraIngresada;
                        VisibilidadBotones(true);
                    }
                        
                }
            }
        }


        public async void DeshabilitarCamposNoUsados()//las palabras ingresadas por lo menos van a tener 4 letras
        {
            if (servicio != null)
            {
                mensajePartidaEjecucion = await servicio.recuperarPartidaEjecucionAsync(infoPartida.IdPartida);
                if (mensajePartidaEjecucion.partidaEjecucion != null)
                {
                    if (mensajePartidaEjecucion.partidaEjecucion.Palabra.Length < 3)
                        tfLetraTres.Visibility = Visibility.Collapsed;
                    if (mensajePartidaEjecucion.partidaEjecucion.Palabra.Length < 4)
                        tfLetraCuatro.Visibility = Visibility.Collapsed;
                    if (mensajePartidaEjecucion.partidaEjecucion.Palabra.Length < 5)
                        tfLetraCinco.Visibility = Visibility.Collapsed;
                    if (mensajePartidaEjecucion.partidaEjecucion.Palabra.Length < 6)
                        tfLetraSeis.Visibility = Visibility.Collapsed;
                    if (mensajePartidaEjecucion.partidaEjecucion.Palabra.Length < 7)
                        tfLetraSiete.Visibility = Visibility.Collapsed;
                    if (mensajePartidaEjecucion.partidaEjecucion.Palabra.Length < 8)
                        tfLetraOcho.Visibility = Visibility.Collapsed;
                    if (mensajePartidaEjecucion.partidaEjecucion.Palabra.Length < 9)
                        tfLetraNueve.Visibility = Visibility.Collapsed;
                    lbPalabraSelecciona.Content = mensajePartidaEjecucion.partidaEjecucion.Palabra;
                }
            }

        }

        private void ClicLetraEquivocada(object sender, RoutedEventArgs e)
        {
            if (!mensajePartidaEjecucion.partidaEjecucion.Palabra.Contains(tbLetra.Text))//comprobar que no miente
            {

                RegistrarJugadaEquivocada();
            }
            else
            {
                MessageBox.Show("La palabra escogida si contiene la letra ingresada");
            }
        }

        private void ActualizarVictoriaAhorcadoFigura(int erroresActuales)
        {

            if (erroresActuales == 1)
            {

                figuraCeroAhorcado.Visibility = Visibility.Collapsed;
                figuraUnoAhorcado.Visibility = Visibility.Visible;
            }
            if (erroresActuales == 2)
            {
                figuraUnoAhorcado.Visibility = Visibility.Collapsed;
                figuraDosAhorcado.Visibility = Visibility.Visible;
            }
            if (erroresActuales == 3)
            {
                figuraDosAhorcado.Visibility = Visibility.Collapsed;
                figuraTresAhorcado.Visibility = Visibility.Visible;
            }
            if (erroresActuales == 4)
            {
                figuraTresAhorcado.Visibility = Visibility.Collapsed;
                figuraCuatroAhorcado.Visibility = Visibility.Visible;
            }
            if (erroresActuales == 5)
            {
                figuraCuatroAhorcado.Visibility = Visibility.Collapsed;
                figuraCincoAhorcado.Visibility = Visibility.Visible;
            }
            if (erroresActuales == 6)
            {
                figuraCincoAhorcado.Visibility = Visibility.Collapsed;
                figuraSeisAhorcado.Visibility = Visibility.Visible;
            }
        }



        private async void RegistrarJugadaEquivocada()
        {
            if (servicio != null)
            {
                if (mensajePartidaEjecucion.partidaEjecucion.CantidadErrores == 5)
                {//la jugada actual es la ultima que se podia equivocar
                    Mensaje mensajeDerrota = await servicio.RegistrarFinPartidaEjecucionAsync(mensajePartidaEjecucion.partidaEjecucion.IdPartidaEjecucion, false);
                    ActualizarVictoriaAhorcadoFigura(6);
                    MessageBox.Show("juego finalizado, El jugador 2 perdio");
                    temporizador.Stop();
                    CargarPantallaSalas();


                }
                else//peude seguir jugando
                {

                    Mensaje mensaje = await servicio.RegistrarJugadaEquivocadaAsync(2, mensajePartidaEjecucion.partidaEjecucion.CantidadErrores + 1, mensajePartidaEjecucion.partidaEjecucion.IdPartidaEjecucion);
                    ActualizarVictoriaAhorcadoFigura(mensajePartidaEjecucion.partidaEjecucion.CantidadErrores + 1);
                    tbLetra.Text = "";
                    VisibilidadBotones(false);
                    temporizador.Start();
                }

            }
        }

        private void ClicSiguiente(object sender, RoutedEventArgs e)
        {
            if (!mensajePartidaEjecucion.partidaEjecucion.Palabra.Contains(tbLetra.Text))
            {
                MessageBox.Show("La letra no coincide con alguna. Favor de verificar o presionar letra equivocada");

            }
            else
            {
                ComprobarLugarLetra();
            }
        }

        private  void ComprobarLugarLetra()
        {
            temporizador.Stop();
            string palabra = mensajePartidaEjecucion.partidaEjecucion.Palabra;
            string letra = tbLetra.Text;
            bool validacion = true;
            if (camposUsados[0] == 0 && palabra.Length >= 1 && tfLetraUno.Text != null && palabra[0].ToString().ToLower().Equals(letra))
            {
                if (tfLetraUno.Text == letra && palabra[0].ToString().Equals(letra))//verifica que la letra ingresada sea la misma que la ingresada por el jugador uno
                {
                    camposUsados[0] = 1;
                    tfLetraUno.IsReadOnly = true;
                    tfLetraUno.Background = new SolidColorBrush(Color.FromRgb(40, 187, 40));
                }
                else
                {
                    validacion = false;
                }
            }
            if (camposUsados[1] == 0 && palabra.Length >= 2 && tfLetraDos.Text != null && palabra[1].ToString().ToLower().Equals(letra))
            {
                if (tfLetraDos.Text == letra && palabra[1].ToString().Equals(letra))//verifica que la letra ingresada sea la misma que la ingresada por el jugador uno
                {
                    camposUsados[1] = 1;
                    tfLetraDos.IsReadOnly = true;
                    tfLetraDos.Background = new SolidColorBrush(Color.FromRgb(40, 187, 40));
                }
                else
                {
                    validacion = false;
                }
            }
            if (camposUsados[2] == 0 && palabra.Length >= 3 && tfLetraTres.Text != null && palabra[2].ToString().ToLower().Equals(letra))
            {
                if (tfLetraTres.Text == letra && palabra[2].ToString().Equals(letra))//verifica que la letra ingresada sea la misma que la ingresada por el jugador uno
                {
                    camposUsados[2] = 1;
                    tfLetraTres.IsReadOnly = true;
                    tfLetraTres.Background = new SolidColorBrush(Color.FromRgb(40, 187, 40));
                }
                else
                {
                    validacion = false;
                }
            }
            if (camposUsados[3] == 0 && palabra.Length >= 4 && tfLetraCuatro.Text != null && palabra[3].ToString().ToLower().Equals(letra))
            {
                if (tfLetraCuatro.Text == letra && palabra[3].ToString().Equals(letra))//verifica que la letra ingresada sea la misma que la ingresada por el jugador uno
                {
                    camposUsados[3] = 1;
                    tfLetraCuatro.IsReadOnly = true;
                    tfLetraCuatro.Background = new SolidColorBrush(Color.FromRgb(40, 187, 40));
                }
                else
                {
                    validacion = false;
                }
            }
            if (camposUsados[4] == 0 && palabra.Length >= 5 && tfLetraCinco.Text != null && palabra[4].ToString().ToLower().Equals(letra))
            {
                if (tfLetraCinco.Text == letra && palabra[4].ToString().Equals(letra))//verifica que la letra ingresada sea la misma que la ingresada por el jugador uno
                {
                    camposUsados[4] = 1;
                    tfLetraCinco.IsReadOnly = true;
                    tfLetraCinco.Background = new SolidColorBrush(Color.FromRgb(40, 187, 40));
                }
                else
                {
                    validacion = false;
                }
            }
            if (camposUsados[5] == 0 && palabra.Length >= 6 && tfLetraSeis.Text != null && palabra[5].ToString().ToLower().Equals(letra))
            {
                if (tfLetraSeis.Text == letra && palabra[5].ToString().Equals(letra))//verifica que la letra ingresada sea la misma que la ingresada por el jugador uno
                {
                    camposUsados[5] = 1;
                    tfLetraSeis.IsReadOnly = true;
                    tfLetraSeis.Background = new SolidColorBrush(Color.FromRgb(40, 187, 40));
                }
                else
                {
                    validacion = false;
                }
            }
            if (camposUsados[6] == 0 && palabra.Length >= 7 && tfLetraSiete.Text != null && palabra[6].ToString().ToLower().Equals(letra))
            {
                if (tfLetraSiete.Text == letra && palabra[6].ToString().Equals(letra))//verifica que la letra ingresada sea la misma que la ingresada por el jugador uno
                {
                    camposUsados[6] = 1;
                    tfLetraSiete.IsReadOnly = true;
                    tfLetraSiete.Background = new SolidColorBrush(Color.FromRgb(40, 187, 40));
                }
                else
                {
                    validacion = false;
                }
            }
            if (camposUsados[7] == 0 && palabra.Length >= 8 && tfLetraOcho.Text != null && palabra[7].ToString().ToLower().Equals(letra))
            {
                if (tfLetraOcho.Text == letra && palabra[7].ToString().Equals(letra))//verifica que la letra ingresada sea la misma que la ingresada por el jugador uno
                {
                    camposUsados[7] = 1;
                    tfLetraOcho.IsReadOnly = true;
                    tfLetraOcho.Background = new SolidColorBrush(Color.FromRgb(40, 187, 40));
                }
                else
                {
                    validacion = false;
                }
            }
            if (camposUsados[8] == 0 && palabra.Length >= 9 && tfLetraNueve.Text != null && palabra[8].ToString().ToLower().Equals(letra))
            {
                if (tfLetraNueve.Text == letra && palabra[8].ToString().Equals(letra))//verifica que la letra ingresada sea la misma que la ingresada por el jugador uno
                {
                    camposUsados[8] = 1;
                    tfLetraNueve.IsReadOnly = true;
                    tfLetraNueve.Background = new SolidColorBrush(Color.FromRgb(40, 187, 40));
                }
                else
                {
                    validacion = false;
                }
            }

            if (!validacion)
            {
                MessageBox.Show("Alguna letra no coincide o no se colocó la letra correspondiente. Favor de verificar");
            }
            else//cambiar de turno
            {
                if (ComprobarPalabraCompleta())
                {

                    ActualizarVictoria();
                }
                else
                {
                   // MessageBox.Show("pasar turno: linea 426");
                    PasarTurno();
                }
                    
            }

        }

        private async void ActualizarVictoria()
        {
            if (servicio != null)
            {
                Mensaje registroVicoria = new Mensaje();
                registroVicoria = await servicio.RegistrarFinPartidaEjecucionAsync(mensajePartidaEjecucion.partidaEjecucion.IdPartidaEjecucion, true);
                if (registroVicoria!=null && !registroVicoria.Error )
                {
                    temporizador.Stop();
                    MessageBox.Show("La PARTIDA ha finalizado,el jugador 2 ha ganado");
                    CargarPantallaSalas();
                }else
                {
                    ActualizarVictoria();
                }
            }
            else
            {
                MessageBox.Show("El servicio no se encuentra disponible:Metodo_ActualiarVictoria");
            }
        }

        private async void CargarPantallaSalas()
        {
            if (servicio != null)
            {
                RespuestaLogin recuperacionUsuario = new RespuestaLogin();
                recuperacionUsuario = await servicio.RecuperarInformacionUsuarioAsync(mensajePartidaEjecucion.partidaEjecucion.IdUsuarioUno);
                if (recuperacionUsuario.UsuarioCorrecto)
                {
                    Salas salas = new Salas();
                    salas.PasarUsuario(recuperacionUsuario.InformacionUsuario);
                    this.Close();
                    salas.Show();

                }
                else
                {
                    MessageBox.Show("Ocurrio un error al recuperar al usuario: metodo_CargarPantallaSalas_Jugador1: " + mensajePartidaEjecucion.partidaEjecucion.IdUsuarioUno);
                    CargarPantallaSalas();
                }
            }
            else
            {
                MessageBox.Show("Servicio no disponible: Metodo_CargarPantallaSalas_Jugador1");
            }

        }
        private Boolean ComprobarPalabraCompleta()
        {
            // MessageBox.Show("Dentro de metodo ComporbarPalarbaCp,[;eta");
            Boolean validacion = true;
            string palabraArmada = "";
            string palabraOriginal = mensajePartidaEjecucion.partidaEjecucion.Palabra;

            if (palabraOriginal.Length >= 1)
                palabraArmada += tfLetraUno.Text;
            if (palabraOriginal.Length >= 2)
                palabraArmada += tfLetraDos.Text;
            if (palabraOriginal.Length >= 3)
                palabraArmada += tfLetraTres.Text;
            if (palabraOriginal.Length >= 4)
                palabraArmada += tfLetraCuatro.Text;
            if (palabraOriginal.Length >= 5)
                palabraArmada += tfLetraCinco.Text;
            if (palabraOriginal.Length >= 6)
                palabraArmada += tfLetraSeis.Text;
            if (palabraOriginal.Length >= 7)
                palabraArmada += tfLetraSiete.Text;
            if (palabraOriginal.Length >= 8)
                palabraArmada += tfLetraOcho.Text;
            if (palabraOriginal.Length >= 9)
                palabraArmada += tfLetraNueve.Text;

            if (!palabraOriginal.Equals(palabraArmada))
                validacion = false;
            
            return validacion;
        }

        private async void PasarTurno()//cuando la jugada es valida
        {
            if (servicio != null)
            {
                Mensaje mensaje = new Mensaje();

                mensaje = await servicio.RegistrarJugadaJugadorDosAsync(2, mensajePartidaEjecucion.partidaEjecucion.LetraIngresada, mensajePartidaEjecucion.partidaEjecucion.IdPartidaEjecucion);

                if (mensaje.Error != null && mensaje.Error)
                {
                    MessageBox.Show("hubo un error al pasar turno, por lo que se llamara asi mismo: metodo_PasarTurno"
                        +"DATOS DEL OBJETO A USAR:\n" 
                        +"turno a colocar: 2, \nletra:"+ mensajePartidaEjecucion.partidaEjecucion.LetraIngresada + "\nid de palrtida ejecucion: "+ mensajePartidaEjecucion.partidaEjecucion.IdPartidaEjecucion
                         + "EXCEPCION MENSAJE"+ mensaje.MensajeRespuesta   );
                    PasarTurno();
                }
                    
                else
                {
                    tbLetra.Text = "";
                    VisibilidadBotones(false);
                    temporizador.Start();
                }


            }
        }

        private void ClicTerminarPartida(object sender, RoutedEventArgs e)
        {
            CancelarPartida();
        }

        private async void CancelarPartida()
        {
            Mensaje respuestaCancelacion = new Mensaje();
            if (servicio != null)
            {
                respuestaCancelacion = await servicio.CancelarPartidaEjecucionAsync(mensajePartidaEjecucion.partidaEjecucion.IdPartidaEjecucion, 2, mensajePartidaEjecucion.partidaEjecucion.IdPartida);

                if (!respuestaCancelacion.Error)
                {
                    temporizador.Stop();
                    MessageBox.Show("Partida Cancelada");

                    CargarPantallaSalas();
                }
            }
        }



        private void VisibilidadBotones(bool visibilidad)
        {
            if(visibilidad)
            {
                btnLetraEquivocada.Visibility = Visibility.Visible;
                btnSiguiente.Visibility = Visibility.Visible;
                btnTerminarPartida.Visibility = Visibility.Visible;
            }
            else
            {
                btnLetraEquivocada.Visibility = Visibility.Collapsed;
                btnSiguiente.Visibility = Visibility.Collapsed;
               // btnTerminarPartida.Visibility = Visibility.Collapsed;
            }
        }

        //agregar un contador al clic siguiente para saber que ya ingreso las letras correctas y saber que ya la completo en base al tamaño de la palabra, despues de todas las verificaciones
    }
}
