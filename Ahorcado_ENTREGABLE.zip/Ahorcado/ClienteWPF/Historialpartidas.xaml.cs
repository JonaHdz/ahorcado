﻿using ServiceReference1;
using System.Windows;

namespace ClienteWPF
{
    /// <summary>
    /// Lógica de interacción para Historialpartidas.xaml
    /// </summary>
    public partial class Historialpartidas : Window
    {
        private ServicioJuegoClient servicio;

        public Historialpartidas(Usuario usuario)
        {
            InitializeComponent();
            servicio = new ServicioJuegoClient();
            CargarHistorialTabla(usuario.IdUsuario);

        }

        private  async void CargarHistorialTabla(int idUsuario)
        {
            
            if (servicio != null)
            {
               
                MensajeHistorialPartida partidasRecuperadas = new MensajeHistorialPartida();
                
                partidasRecuperadas = await servicio.RecuperarHistorialpartidasAsync(idUsuario);
                
                if (partidasRecuperadas != null || !partidasRecuperadas.Error)
                {
                    dgHistorialPartidas.ItemsSource = partidasRecuperadas.PartidasRecuperadas;
                    int puntajeGlobal = 0;
                    foreach (HistorialPartida partidaIndividual in partidasRecuperadas.PartidasRecuperadas)
                        puntajeGlobal += partidaIndividual.Puntaje;

                    lbPuntajeGlobal.Content = puntajeGlobal;
                }else
                {
                    CargarHistorialTabla(idUsuario);
                }
            }
            else
            {
                MessageBox.Show("Servicio no disponible");
            }
        }

        private void ClicCerrar(object sender, RoutedEventArgs e)
        {
            this.Close();
        }
    }
}
