﻿using ServiceReference1;
using System;
using System.Windows;

namespace ClienteWPF
{
    /// <summary>
    /// Lógica de interacción para FormularioRegistroUsuario.xaml
    /// </summary>
    public partial class FormularioRegistroUsuario : Window
    {
        private Usuario usuarioEdicion;//para editar
        private Boolean edicion;//para saber si era un registro o edicion
                                // private Notificacion notificacion;
        private NotificacionEdicionUsuario notificacion;
        ServicioJuegoClient servicios;

        public FormularioRegistroUsuario()
        {
            InitializeComponent();
            servicios = new ServicioJuegoClient();
        }

        public void IniciarValores(Boolean edicion, Usuario usuarioEdicion, NotificacionEdicionUsuario notificacion)
        {
            this.usuarioEdicion = usuarioEdicion;
            this.edicion = edicion;
            this.notificacion = notificacion;
            if (edicion)
            {
                tbCorreo.Text = usuarioEdicion.Correo;
                tbFechaNacimiento.Text = usuarioEdicion.FechaNacimiento;
                tbNombreCompleto.Text = usuarioEdicion.NombreCompleto;
                tbPssword.Text = usuarioEdicion.Password;
                tbTelefono.Text = usuarioEdicion.Telefono;
                tbCorreo.IsEnabled = false;
            }

        }

        private async void clicGuardar(object sender, RoutedEventArgs e)
        {



            Usuario usuario = generarUsuario();
            if (edicion == false)
            {
                if (servicios != null)
                {
                    Mensaje respuestaRegistro = await servicios.RegistrarUsuarioAsync(usuario);
                    if (respuestaRegistro.Error == false)
                    {
                        MessageBox.Show(respuestaRegistro.MensajeRespuesta);
                        this.Close();

                    }
                    else
                    {
                        MessageBox.Show(respuestaRegistro.MensajeRespuesta);
                    }

                }
                else
                {

                    MessageBox.Show("ERROR CON EL SERVICIO");
                }

            }
            else//parte de actualizar usuario
            {
                if (servicios != null)
                {
                    RespuestaLogin respuestaLogin = await servicios.ActualizarUsuarioAsync(usuario);
                    if (!respuestaLogin.UsuarioCorrecto)
                    {
                        MessageBox.Show(respuestaLogin.Mensaje);
                        notificacion.actualizarUsuario(usuario);
                        this.Close();
                    }
                    else
                    {
                        MessageBox.Show(respuestaLogin.Mensaje);
                    }


                }

            }

        }

        private void clicCancelar(object sender, RoutedEventArgs e)
        {
            this.Close();

        }

        private Usuario generarUsuario()
        {
            Usuario usuario = new Usuario();
            usuario.NombreCompleto = tbNombreCompleto.Text;
            usuario.Correo = tbCorreo.Text;
            usuario.FechaNacimiento = tbFechaNacimiento.Text;
            usuario.Password = tbPssword.Text;
            usuario.Telefono = tbTelefono.Text;
            if (edicion)
            {
                usuario.IdUsuario = usuarioEdicion.IdUsuario;
            }

            return usuario;
        }
    }
}
