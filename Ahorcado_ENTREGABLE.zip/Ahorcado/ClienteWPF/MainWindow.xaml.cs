﻿using ServiceReference1;
using System.Windows;

namespace ClienteWPF
{
    public partial class MainWindow : Window
    {
        ServicioJuegoClient servicios;
        public MainWindow()
        {
            InitializeComponent();
            servicios = new ServicioJuegoClient();
        }



        private async void ClicIngresar(object sender, RoutedEventArgs e)
        {
            if (servicios != null)
            {
    
                RespuestaLogin respuestaIngreso = await servicios.ValidarUsuarioAsync(tbCorreo.Text, tbPassword.Password.ToString());
                if (respuestaIngreso.UsuarioCorrecto)
                {
                    AbrirVentanaSalas(respuestaIngreso.InformacionUsuario);

                }
                else
                {
                    MessageBox.Show(respuestaIngreso.Mensaje);
                }
            }
            else
            {
                MessageBox.Show("FALLO EN SERVICIO");
            }


        }

        private void AbrirVentanaSalas(Usuario UsuarioLogin)
        {
            Salas stage = new Salas();
            stage.PasarUsuario(UsuarioLogin);
            stage.Show();
            this.Close();
        }


        private void ClicCerrar(object sender, RoutedEventArgs e)
        {
            this.Close();
        }

        private void ClicRegistrarse(object sender, RoutedEventArgs e)
        {
            FormularioRegistroUsuario stage = new FormularioRegistroUsuario();
            stage.IniciarValores(false, null, null);
            stage.Show();

        }

        private void tbCorreo_TextChanged(object sender, System.Windows.Controls.TextChangedEventArgs e)
        {

        }

        private void tbCorreo_TextChanged_1(object sender, System.Windows.Controls.TextChangedEventArgs e)
        {

        }
    }
}
