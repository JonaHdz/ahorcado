﻿using ServiceReference1;
using System;
using System.Windows;
using System.Windows.Threading;

namespace ClienteWPF
{
    /// <summary>
    /// Lógica de interacción para Jugador2.xaml
    /// </summary>

    public partial class Jugador2 : Window
    {
        private ServicioJuegoClient servicio;
        private Partida infoPartida;
        private DispatcherTimer temporizador;
        MensajePartidaEjecucion partidaRecuperada = new MensajePartidaEjecucion();
        private EsperaTurnoJugador ventanaEsperaTurno;
        private int erroresPrevios;//usado para verificar si hay cambio en los errores tras cada jugada

        public Jugador2()
        {
            InitializeComponent();
            servicio = new ServicioJuegoClient();
            erroresPrevios = 0;
            temporizador = new DispatcherTimer();
            temporizador.Interval = new TimeSpan(0, 0, 0, 3);//cada  segundo
            temporizador.Tick += (a, b) =>
            {
                VerificarTurnoJugador();
            };
        }

        public void DeshabilitarEdicionCampos()
        {
            tfLetraUno.IsReadOnly = true;
            tfLetraDos.IsReadOnly = true;
            tfLetraTres.IsReadOnly = true;
            tfLetraCuatro.IsReadOnly = true;
            tfLetraCinco.IsReadOnly = true;
            tfLetraSeis.IsReadOnly = true;
            tfLetraSiete.IsReadOnly = true;
            tfLetraOcho.IsReadOnly = true;
            tfLetraNueve.IsReadOnly = true;

        }

        public void DeshabilitarCamposNoUsados()//las palabras ingresadas por lo menos van a tener 4 letras
        {
            // MessageBox.Show("cantidad de letras: " + partidaRecuperada.partidaEjecucion.Palabra.Length);
            if (partidaRecuperada.partidaEjecucion.Palabra.Length < 3)
                tfLetraTres.Visibility = Visibility.Collapsed;
            if (partidaRecuperada.partidaEjecucion.Palabra.Length < 4)
                tfLetraCuatro.Visibility = Visibility.Collapsed;
            if (partidaRecuperada.partidaEjecucion.Palabra.Length < 5)
                tfLetraCinco.Visibility = Visibility.Collapsed;
            if (partidaRecuperada.partidaEjecucion.Palabra.Length < 6)
                tfLetraSeis.Visibility = Visibility.Collapsed;
            if (partidaRecuperada.partidaEjecucion.Palabra.Length < 7)
                tfLetraSiete.Visibility = Visibility.Collapsed;
            if (partidaRecuperada.partidaEjecucion.Palabra.Length < 8)
                tfLetraOcho.Visibility = Visibility.Collapsed;
            if (partidaRecuperada.partidaEjecucion.Palabra.Length < 9)
                tfLetraNueve.Visibility = Visibility.Collapsed;
            temporizador.Start();
        }



        public void CargarDatosPartida(MensajePartida mensajePartida)
        {
            infoPartida = mensajePartida.Partida;
            CargarElementosJuego();
            

        }

        private async void CargarElementosJuego()
        {
            if (servicio != null)
            {
                partidaRecuperada = await servicio.recuperarPartidaEjecucionAsync(infoPartida.IdPartida);
                if (!partidaRecuperada.Error && partidaRecuperada.partidaEjecucion != null)
                    lbDescripcion.Content = partidaRecuperada.partidaEjecucion.DescripcionPalabra;
                DeshabilitarCamposNoUsados();
            }
        }

        private async void ClicBotonA(object sender, RoutedEventArgs e)
        {
            if (servicio != null)
            {
                Mensaje respuestaJugada = new Mensaje();
                respuestaJugada.MensajeRespuesta = "X";
                btnA.IsEnabled = false;
                respuestaJugada = await servicio.RegistrarJugadaJugadorDosAsync(1, "a", partidaRecuperada.partidaEjecucion.IdPartidaEjecucion);
                if (respuestaJugada == null || respuestaJugada.Error == true)
                {
                    MessageBox.Show("respuestaJugada fue null o fue error: " + respuestaJugada.MensajeRespuesta + ". Datos que se pasaron al servicio: \n turno:1 \nuna letra \n idPartidaEjecucion:  " + partidaRecuperada.partidaEjecucion.IdPartidaEjecucion); ClicBotonA(sender, e);
                }

                else
                {
                    VisibilidadBotones(false);


                    temporizador.Start();

                }
            }
        }

        private async void ClicBotonB(object sender, RoutedEventArgs e)
        {
            if (servicio != null)
            {
                Mensaje respuestaJugada = new Mensaje();
                respuestaJugada.MensajeRespuesta = "X";
                btnB.IsEnabled = false;
                respuestaJugada = await servicio.RegistrarJugadaJugadorDosAsync(1, "b", partidaRecuperada.partidaEjecucion.IdPartidaEjecucion);
                if (respuestaJugada == null || respuestaJugada.Error == true)
                {
                    MessageBox.Show("respuestaJugada fue null o fue error: " + respuestaJugada.MensajeRespuesta + ". Datos que se pasaron al servicio: \n turno:1 \nuna letra \n idPartidaEjecucion:  " + partidaRecuperada.partidaEjecucion.IdPartidaEjecucion);
                    ClicBotonB(sender, e);
                }

                else
                {
                    VisibilidadBotones(false);
                    temporizador.Start();
                }

            }
        }

        private async void ClicBotonC(object sender, RoutedEventArgs e)
        {
            if (servicio != null)
            {
                Mensaje respuestaJugada = new Mensaje();
                respuestaJugada.MensajeRespuesta = "X";
                btnC.IsEnabled = false;
                respuestaJugada = await servicio.RegistrarJugadaJugadorDosAsync(1, "c", partidaRecuperada.partidaEjecucion.IdPartidaEjecucion);
                if (respuestaJugada == null || respuestaJugada.Error == true)
                {
                    MessageBox.Show("respuestaJugada fue null o fue error: " + respuestaJugada.MensajeRespuesta + ". Datos que se pasaron al servicio: \n turno:1 \nuna letra \n idPartidaEjecucion:  " + partidaRecuperada.partidaEjecucion.IdPartidaEjecucion);
                    ClicBotonC(sender, e);
                }

                else
                {
                    VisibilidadBotones(false);
                    temporizador.Start();
                }

            }
        }

        private async void ClicBotonD(object sender, RoutedEventArgs e)
        {
            if (servicio != null)
            {
                Mensaje respuestaJugada = new Mensaje();
                respuestaJugada.MensajeRespuesta = "X";
                btnD.IsEnabled = false;
                respuestaJugada = await servicio.RegistrarJugadaJugadorDosAsync(1, "d", partidaRecuperada.partidaEjecucion.IdPartidaEjecucion);
                if (respuestaJugada == null || respuestaJugada.Error == true)
                {
                    MessageBox.Show("respuestaJugada fue null o fue error: " + respuestaJugada.MensajeRespuesta + ". Datos que se pasaron al servicio: \n turno:1 \nuna letra \n idPartidaEjecucion:  " + partidaRecuperada.partidaEjecucion.IdPartidaEjecucion);
                    ClicBotonD(sender, e);
                }

                else
                {
                    VisibilidadBotones(false);
                    temporizador.Start();
                }

            }
        }

        private async void ClicBotonE(object sender, RoutedEventArgs e)
        {
            if (servicio != null)
            {
                Mensaje respuestaJugada = new Mensaje();
                respuestaJugada.MensajeRespuesta = "X";
                btnE.IsEnabled = false;
                respuestaJugada = await servicio.RegistrarJugadaJugadorDosAsync(1, "e", partidaRecuperada.partidaEjecucion.IdPartidaEjecucion);
                if (respuestaJugada == null || respuestaJugada.Error == true)
                {
                    MessageBox.Show("respuestaJugada fue null o fue error: " + respuestaJugada.MensajeRespuesta + ". Datos que se pasaron al servicio: \n turno:1 \nuna letra \n idPartidaEjecucion:  " + partidaRecuperada.partidaEjecucion.IdPartidaEjecucion);
                    ClicBotonE(sender, e);
                }

                else
                {
                    VisibilidadBotones(false);
                    temporizador.Start();
                }
            }
        }

        private async void ClicBotonF(object sender, RoutedEventArgs e)
        {
            if (servicio != null)
            {
                Mensaje respuestaJugada = new Mensaje();
                respuestaJugada.MensajeRespuesta = "X";
                btnF.IsEnabled = false;
                respuestaJugada = await servicio.RegistrarJugadaJugadorDosAsync(1, "f", partidaRecuperada.partidaEjecucion.IdPartidaEjecucion);
                if (respuestaJugada == null || respuestaJugada.Error == true)
                {
                    MessageBox.Show("respuestaJugada fue null o fue error: " + respuestaJugada.MensajeRespuesta + ". Datos que se pasaron al servicio: \n turno:1 \nuna letra \n idPartidaEjecucion:  " + partidaRecuperada.partidaEjecucion.IdPartidaEjecucion);
                    ClicBotonF(sender, e);
                }

                else
                {
                    VisibilidadBotones(false);
                    temporizador.Start();
                }
            }
        }

        private async void ClicBotonG(object sender, RoutedEventArgs e)
        {
            if (servicio != null)
            {
                Mensaje respuestaJugada = new Mensaje();
                respuestaJugada.MensajeRespuesta = "X";
                btnG.IsEnabled = false;
                respuestaJugada = await servicio.RegistrarJugadaJugadorDosAsync(1, "g", partidaRecuperada.partidaEjecucion.IdPartidaEjecucion);
                if (respuestaJugada == null || respuestaJugada.Error == true)
                {
                    MessageBox.Show("respuestaJugada fue null o fue error: " + respuestaJugada.MensajeRespuesta + ". Datos que se pasaron al servicio: \n turno:1 \nuna letra \n idPartidaEjecucion:  " + partidaRecuperada.partidaEjecucion.IdPartidaEjecucion);
                    ClicBotonG(sender, e);
                }

                else
                {
                    VisibilidadBotones(false);
                    temporizador.Start();
                }
            }
        }

        private async void ClicBotonH(object sender, RoutedEventArgs e)
        {
            if (servicio != null)
            {
                Mensaje respuestaJugada = new Mensaje();
                respuestaJugada.MensajeRespuesta = "X";
                btnH.IsEnabled = false;
                respuestaJugada = await servicio.RegistrarJugadaJugadorDosAsync(1, "h", partidaRecuperada.partidaEjecucion.IdPartidaEjecucion);
                if (respuestaJugada == null || respuestaJugada.Error == true)
                {
                    MessageBox.Show("respuestaJugada fue null o fue error: " + respuestaJugada.MensajeRespuesta + ". Datos que se pasaron al servicio: \n turno:1 \nuna letra \n idPartidaEjecucion:  " + partidaRecuperada.partidaEjecucion.IdPartidaEjecucion);
                    ClicBotonH(sender, e);
                }

                else
                {
                    VisibilidadBotones(false);
                    temporizador.Start();
                }
            }
        }

        private async void ClicBotonI(object sender, RoutedEventArgs e)
        {
            if (servicio != null)
            {
                Mensaje respuestaJugada = new Mensaje();
                respuestaJugada.MensajeRespuesta = "X";
                btnI.IsEnabled = false;
                respuestaJugada = await servicio.RegistrarJugadaJugadorDosAsync(1, "i", partidaRecuperada.partidaEjecucion.IdPartidaEjecucion);
                if (respuestaJugada == null || respuestaJugada.Error == true)
                {
                    MessageBox.Show("respuestaJugada fue null o fue error: " + respuestaJugada.MensajeRespuesta + ". Datos que se pasaron al servicio: \n turno:1 \nuna letra \n idPartidaEjecucion:  " + partidaRecuperada.partidaEjecucion.IdPartidaEjecucion);
                    ClicBotonI(sender, e);
                }

                else
                {
                    VisibilidadBotones(false);
                    temporizador.Start();
                }
            }
        }

        private async void ClicBotonJ(object sender, RoutedEventArgs e)
        {
            if (servicio != null)
            {
                Mensaje respuestaJugada = new Mensaje();
                respuestaJugada.MensajeRespuesta = "X";
                btnJ.IsEnabled = false;
                respuestaJugada = await servicio.RegistrarJugadaJugadorDosAsync(1, "j", partidaRecuperada.partidaEjecucion.IdPartidaEjecucion);
                if (respuestaJugada == null || respuestaJugada.Error == true)
                {
                    MessageBox.Show("respuestaJugada fue null o fue error: " + respuestaJugada.MensajeRespuesta + ". Datos que se pasaron al servicio: \n turno:1 \nuna letra \n idPartidaEjecucion:  " + partidaRecuperada.partidaEjecucion.IdPartidaEjecucion);
                    ClicBotonJ(sender, e);
                }

                else
                {
                    VisibilidadBotones(false);
                    temporizador.Start();
                }
            }
        }

        private async void ClicBotonK(object sender, RoutedEventArgs e)
        {
            if (servicio != null)
            {
                Mensaje respuestaJugada = new Mensaje();
                respuestaJugada.MensajeRespuesta = "X";
                btnK.IsEnabled = false;
                respuestaJugada = await servicio.RegistrarJugadaJugadorDosAsync(1, "k", partidaRecuperada.partidaEjecucion.IdPartidaEjecucion);
                if (respuestaJugada == null || respuestaJugada.Error == true)
                {
                    MessageBox.Show("respuestaJugada fue null o fue error: " + respuestaJugada.MensajeRespuesta + ". Datos que se pasaron al servicio: \n turno:1 \nuna letra \n idPartidaEjecucion:  " + partidaRecuperada.partidaEjecucion.IdPartidaEjecucion);
                    ClicBotonK(sender, e);
                }

                else
                {
                    VisibilidadBotones(false);
                    temporizador.Start();
                }
            }
        }

        private async void ClicBotonL(object sender, RoutedEventArgs e)
        {
            if (servicio != null)
            {
                Mensaje respuestaJugada = new Mensaje();
                respuestaJugada.MensajeRespuesta = "X";
                btnL.IsEnabled = false;
                respuestaJugada = await servicio.RegistrarJugadaJugadorDosAsync(1, "l", partidaRecuperada.partidaEjecucion.IdPartidaEjecucion);
                if (respuestaJugada == null || respuestaJugada.Error == true)
                {
                    MessageBox.Show("respuestaJugada fue null o fue error: " + respuestaJugada.MensajeRespuesta + ". Datos que se pasaron al servicio: \n turno:1 \nuna letra \n idPartidaEjecucion:  " + partidaRecuperada.partidaEjecucion.IdPartidaEjecucion);
                    ClicBotonL(sender, e);
                }

                else
                {
                    VisibilidadBotones(false);
                    temporizador.Start();
                }
            }
        }
        private async void ClicBotonM(object sender, RoutedEventArgs e)
        {
            if (servicio != null)
            {
                Mensaje respuestaJugada = new Mensaje();
                respuestaJugada.MensajeRespuesta = "X";
                btnM.IsEnabled = false;
                respuestaJugada = await servicio.RegistrarJugadaJugadorDosAsync(1, "m", partidaRecuperada.partidaEjecucion.IdPartidaEjecucion);
                if (respuestaJugada == null || respuestaJugada.Error == true)
                {
                    MessageBox.Show("respuestaJugada fue null o fue error: " + respuestaJugada.MensajeRespuesta + ". Datos que se pasaron al servicio: \n turno:1 \nuna letra \n idPartidaEjecucion:  " + partidaRecuperada.partidaEjecucion.IdPartidaEjecucion);
                    ClicBotonM(sender, e);
                }

                else
                {
                    VisibilidadBotones(false);
                    temporizador.Start();
                }
            }
        }

        private async void ClicBotonN(object sender, RoutedEventArgs e)
        {
            if (servicio != null)
            {
                Mensaje respuestaJugada = new Mensaje();
                respuestaJugada.MensajeRespuesta = "X";
                btnN.IsEnabled = false;
                respuestaJugada = await servicio.RegistrarJugadaJugadorDosAsync(1, "n", partidaRecuperada.partidaEjecucion.IdPartidaEjecucion);
                if (respuestaJugada == null || respuestaJugada.Error == true)
                {
                    MessageBox.Show("respuestaJugada fue null o fue error: " + respuestaJugada.MensajeRespuesta + ". Datos que se pasaron al servicio: \n turno:1 \nuna letra \n idPartidaEjecucion:  " + partidaRecuperada.partidaEjecucion.IdPartidaEjecucion);
                    ClicBotonN(sender, e);
                }

                else
                {
                    VisibilidadBotones(false);
                    temporizador.Start();
                }
            }
        }

        private async void ClicBotonÑ(object sender, RoutedEventArgs e)
        {
            if (servicio != null)
            {
                Mensaje respuestaJugada = new Mensaje();
                respuestaJugada.MensajeRespuesta = "X";
                btnÑ.IsEnabled = false;
                respuestaJugada = await servicio.RegistrarJugadaJugadorDosAsync(1, "ñ", partidaRecuperada.partidaEjecucion.IdPartidaEjecucion);
                if (respuestaJugada == null || respuestaJugada.Error == true)
                {
                    MessageBox.Show("respuestaJugada fue null o fue error: " + respuestaJugada.MensajeRespuesta + ". Datos que se pasaron al servicio: \n turno:1 \nuna letra \n idPartidaEjecucion:  " + partidaRecuperada.partidaEjecucion.IdPartidaEjecucion);
                    ClicBotonÑ(sender, e);
                }

                else
                {
                    VisibilidadBotones(false);
                    temporizador.Start();
                }
            }
        }

        private async void ClicBotonO(object sender, RoutedEventArgs e)
        {
            if (servicio != null)
            {
                Mensaje respuestaJugada = new Mensaje();
                respuestaJugada.MensajeRespuesta = "X";
                btnO.IsEnabled = false;
                respuestaJugada = await servicio.RegistrarJugadaJugadorDosAsync(1, "o", partidaRecuperada.partidaEjecucion.IdPartidaEjecucion);
                if (respuestaJugada == null || respuestaJugada.Error == true)
                {
                    MessageBox.Show("respuestaJugada fue null o fue error: " + respuestaJugada.MensajeRespuesta + ". Datos que se pasaron al servicio: \n turno:1 \nuna letra \n idPartidaEjecucion:  " + partidaRecuperada.partidaEjecucion.IdPartidaEjecucion);
                    ClicBotonO(sender, e);
                }

                else
                {
                    VisibilidadBotones(false);
                    temporizador.Start();
                }
            }
        }

        private async void ClicBotonP(object sender, RoutedEventArgs e)
        {
            if (servicio != null)
            {
                Mensaje respuestaJugada = new Mensaje();
                respuestaJugada.MensajeRespuesta = "X";
                btnP.IsEnabled = false;
                respuestaJugada = await servicio.RegistrarJugadaJugadorDosAsync(1, "p", partidaRecuperada.partidaEjecucion.IdPartidaEjecucion);
                if (respuestaJugada == null || respuestaJugada.Error == true)
                {
                    MessageBox.Show("respuestaJugada fue null o fue error: " + respuestaJugada.MensajeRespuesta+". Datos que se pasaron al servicio: \n turno:1 \nuna letra \n idPartidaEjecucion:  "+ partidaRecuperada.partidaEjecucion.IdPartidaEjecucion);
                    ClicBotonP(sender, e);
                }

                else
                {
                    VisibilidadBotones(false);
                    temporizador.Start();
                }
            }
        }

        private async void ClicBotonQ(object sender, RoutedEventArgs e)
        {
            if (servicio != null)
            {
                Mensaje respuestaJugada = new Mensaje();
                respuestaJugada.MensajeRespuesta = "X";
                btnQ.IsEnabled = false;
                respuestaJugada = await servicio.RegistrarJugadaJugadorDosAsync(1, "q", partidaRecuperada.partidaEjecucion.IdPartidaEjecucion);
                if (respuestaJugada == null || respuestaJugada.Error == true)
                {
                    MessageBox.Show("respuestaJugada fue null o fue error: " + respuestaJugada.MensajeRespuesta + ". Datos que se pasaron al servicio: \n turno:1 \nuna letra \n idPartidaEjecucion:  " + partidaRecuperada.partidaEjecucion.IdPartidaEjecucion);
                    ClicBotonQ(sender, e);
                }

                else
                {
                    VisibilidadBotones(false);
                    temporizador.Start();
                }
            }
        }

        private async void ClicBotonR(object sender, RoutedEventArgs e)
        {
            if (servicio != null)
            {
                Mensaje respuestaJugada = new Mensaje();
                respuestaJugada.MensajeRespuesta = "X";
                btnR.IsEnabled = false;
                respuestaJugada = await servicio.RegistrarJugadaJugadorDosAsync(1, "r", partidaRecuperada.partidaEjecucion.IdPartidaEjecucion);
                if (respuestaJugada == null || respuestaJugada.Error == true)
                {
                    MessageBox.Show("respuestaJugada fue null o fue error: " + respuestaJugada.MensajeRespuesta + ". Datos que se pasaron al servicio: \n turno:1 \nuna letra \n idPartidaEjecucion:  " + partidaRecuperada.partidaEjecucion.IdPartidaEjecucion);
                    ClicBotonR(sender, e);
                }

                else
                {
                    VisibilidadBotones(false);
                    temporizador.Start();
                }
            }
        }

        private async void ClicBotonS(object sender, RoutedEventArgs e)
        {
            if (servicio != null)
            {
                Mensaje respuestaJugada = new Mensaje();
                respuestaJugada.MensajeRespuesta = "X";
                btnS.IsEnabled = false;
                respuestaJugada = await servicio.RegistrarJugadaJugadorDosAsync(1, "s", partidaRecuperada.partidaEjecucion.IdPartidaEjecucion);
                if (respuestaJugada == null || respuestaJugada.Error == true)
                {
                    MessageBox.Show("respuestaJugada fue null o fue error: " + respuestaJugada.MensajeRespuesta + ". Datos que se pasaron al servicio: \n turno:1 \nuna letra \n idPartidaEjecucion:  " + partidaRecuperada.partidaEjecucion.IdPartidaEjecucion);
                    ClicBotonS(sender, e);
                }

                else
                {
                    VisibilidadBotones(false);
                    temporizador.Start();
                }
            }
        }

        private async void ClicBotonT(object sender, RoutedEventArgs e)
        {
            if (servicio != null)
            {
                Mensaje respuestaJugada = new Mensaje();
                respuestaJugada.MensajeRespuesta = "X";
                btnT.IsEnabled = false;
                respuestaJugada = await servicio.RegistrarJugadaJugadorDosAsync(1, "t", partidaRecuperada.partidaEjecucion.IdPartidaEjecucion);
                if (respuestaJugada == null || respuestaJugada.Error == true)
                {
                    MessageBox.Show("respuestaJugada fue null o fue error: " + respuestaJugada.MensajeRespuesta + ". Datos que se pasaron al servicio: \n turno:1 \nuna letra \n idPartidaEjecucion:  " + partidaRecuperada.partidaEjecucion.IdPartidaEjecucion);
                    ClicBotonT(sender, e);
                }


                else
                {
                    VisibilidadBotones(false);
                    temporizador.Start();
                }
            }
        }

        private async void ClicBotonU(object sender, RoutedEventArgs e)
        {
            if (servicio != null)
            {
                Mensaje respuestaJugada = new Mensaje();
                respuestaJugada.MensajeRespuesta = "X";
                btnU.IsEnabled = false;
                respuestaJugada = await servicio.RegistrarJugadaJugadorDosAsync(1, "u", partidaRecuperada.partidaEjecucion.IdPartidaEjecucion);
                if (respuestaJugada == null || respuestaJugada.Error == true)
                {
                    MessageBox.Show("respuestaJugada fue null o fue error: " + respuestaJugada.MensajeRespuesta + ". Datos que se pasaron al servicio: \n turno:1 \nuna letra \n idPartidaEjecucion:  " + partidaRecuperada.partidaEjecucion.IdPartidaEjecucion);
                    ClicBotonU(sender, e);
                }

                else
                {
                    VisibilidadBotones(false);
                    temporizador.Start();
                }
            }
        }

        private async void ClicBotonV(object sender, RoutedEventArgs e)
        {
            if (servicio != null)
            {
                Mensaje respuestaJugada = new Mensaje();
                respuestaJugada.MensajeRespuesta = "X";
                btnV.IsEnabled = false;
                respuestaJugada = await servicio.RegistrarJugadaJugadorDosAsync(1, "v", partidaRecuperada.partidaEjecucion.IdPartidaEjecucion);
                if (respuestaJugada == null || respuestaJugada.Error == true)
                {
                    MessageBox.Show("respuestaJugada fue null o fue error: " + respuestaJugada.MensajeRespuesta + ". Datos que se pasaron al servicio: \n turno:1 \nuna letra \n idPartidaEjecucion:  " + partidaRecuperada.partidaEjecucion.IdPartidaEjecucion);
                    ClicBotonV(sender, e);
                }

                else
                {
                    VisibilidadBotones(false);
                    temporizador.Start();
                }
            }
        }

        private async void ClicBotonW(object sender, RoutedEventArgs e)
        {
            if (servicio != null)
            {
                Mensaje respuestaJugada = new Mensaje();
                respuestaJugada.MensajeRespuesta = "X";
                btnW.IsEnabled = false;
                respuestaJugada = await servicio.RegistrarJugadaJugadorDosAsync(1, "w", partidaRecuperada.partidaEjecucion.IdPartidaEjecucion);
                if (respuestaJugada == null || respuestaJugada.Error == true)
                {
                    MessageBox.Show("respuestaJugada fue null o fue error: " + respuestaJugada.MensajeRespuesta + ". Datos que se pasaron al servicio: \n turno:1 \nuna letra \n idPartidaEjecucion:  " + partidaRecuperada.partidaEjecucion.IdPartidaEjecucion);

                    ClicBotonW(sender, e);
                }

                else
                {
                    VisibilidadBotones(false);
                    temporizador.Start();
                }
            }
        }

        private async void ClicBotonX(object sender, RoutedEventArgs e)
        {
            if (servicio != null)
            {
                Mensaje respuestaJugada = new Mensaje();
                respuestaJugada.MensajeRespuesta = "X";
                btnX.IsEnabled = false;
                respuestaJugada = await servicio.RegistrarJugadaJugadorDosAsync(1, "x", partidaRecuperada.partidaEjecucion.IdPartidaEjecucion);
                if (respuestaJugada == null || respuestaJugada.Error == true)
                {
                    MessageBox.Show("respuestaJugada fue null o fue error: " + respuestaJugada.MensajeRespuesta + ". Datos que se pasaron al servicio: \n turno:1 \nuna letra \n idPartidaEjecucion:  " + partidaRecuperada.partidaEjecucion.IdPartidaEjecucion);

                    ClicBotonX(sender, e);
                }

                else
                {
                    VisibilidadBotones(false);
                    temporizador.Start();
                }
            }
        }

        private async void ClicBotonY(object sender, RoutedEventArgs e)
        {
            if (servicio != null)
            {
                Mensaje respuestaJugada = new Mensaje();
                respuestaJugada.MensajeRespuesta = "X";
                btnY.IsEnabled = false;
                respuestaJugada = await servicio.RegistrarJugadaJugadorDosAsync(1, "y", partidaRecuperada.partidaEjecucion.IdPartidaEjecucion);
                if (respuestaJugada == null || respuestaJugada.Error == true)
                {
                    MessageBox.Show("respuestaJugada fue null o fue error: " + respuestaJugada.MensajeRespuesta + ". Datos que se pasaron al servicio: \n turno:1 \nuna letra \n idPartidaEjecucion:  " + partidaRecuperada.partidaEjecucion.IdPartidaEjecucion);

                    ClicBotonY(sender, e);
                }

                else
                {
                    VisibilidadBotones(false);
                    temporizador.Start();
                }
            }
        }

        private async void ClicBotonZ(object sender, RoutedEventArgs e)
        {
            if (servicio != null)
            {
                Mensaje respuestaJugada = new Mensaje();
                respuestaJugada.MensajeRespuesta = "X";
                btnZ.IsEnabled = false;
                respuestaJugada = await servicio.RegistrarJugadaJugadorDosAsync(1, "z", partidaRecuperada.partidaEjecucion.IdPartidaEjecucion);
                if (respuestaJugada == null || respuestaJugada.Error == true)
                {
                    MessageBox.Show("respuestaJugada fue null o fue error: " + respuestaJugada.MensajeRespuesta + ". Datos que se pasaron al servicio: \n turno:1 \nuna letra \n idPartidaEjecucion:  " + partidaRecuperada.partidaEjecucion.IdPartidaEjecucion);

                    ClicBotonZ(sender, e);
                }

                else
                {
                    VisibilidadBotones(false);
                    temporizador.Start();
                }

            }
        }

        public async void AnalizarRespuesta()//metodo de la interfaz uado para actualizar el muñeco si esta equivocada la letraque introdujo
        {

            if (servicio != null)
            {
                partidaRecuperada = await servicio.recuperarPartidaEjecucionAsync(infoPartida.IdPartida);
                if(partidaRecuperada!=null && !partidaRecuperada.Error)
                {
                    int erroresActuales = partidaRecuperada.partidaEjecucion.CantidadErrores;

                    lbErroresCometidos.Content = "" + erroresActuales;
                    if (erroresPrevios < erroresActuales)
                    {
                        erroresPrevios = partidaRecuperada.partidaEjecucion.CantidadErrores;
                        ActualizarMuñeco(erroresActuales);
                        VisibilidadBotones(true);
                        ComprobarDerrota();

                    }
                    else
                    {
                        AgregarLetra();
                        VisibilidadBotones(true);
                        ValidarPalabraCompleta();

                    }
                }else
                {
                    MessageBox.Show("No se pudo recuperar la partida para aanalizarla: metodo_AnalizarRespuesta_Jugador2 \nmensaje: " + partidaRecuperada.Mensaje  );
                    AnalizarRespuesta();
                }

            }

        }

        private void AgregarLetra()//agrega la letra correspondiente en la gui si es que fue correcta
        {
            string letraPrevia = partidaRecuperada.partidaEjecucion.LetraIngresada;
            string palabra = partidaRecuperada.partidaEjecucion.Palabra;
            // MessageBox.Show("dentro del metodo de colocar letra: "+ palabra[0]);
            //MessageBox.Show("letra ingresada: " + letraPrevia);
            if (!letraPrevia.Equals(""))
            {
                if (palabra.Length >= 1)
                {

                    if (palabra[0].Equals(char.Parse(letraPrevia)))
                        tfLetraUno.Text = letraPrevia;
                }

                if (palabra.Length >= 2)
                {
                    if (palabra[1].Equals(char.Parse(letraPrevia)))
                        tfLetraDos.Text = letraPrevia;
                }
                if (palabra.Length >= 3)
                {
                    if (palabra[2].Equals(char.Parse(letraPrevia)))
                        tfLetraTres.Text = letraPrevia;
                }

                if (palabra.Length >= 4)
                {
                    if (palabra[3].Equals(char.Parse(letraPrevia)))
                        tfLetraCuatro.Text = letraPrevia;
                }

                if (palabra.Length >= 5)
                {
                    if (palabra[4].Equals(char.Parse(letraPrevia)))
                        tfLetraCinco.Text = letraPrevia;
                }

                if (palabra.Length >= 6)
                {
                    if (palabra[5].Equals(char.Parse(letraPrevia)))
                        tfLetraSeis.Text = letraPrevia;
                }

                if (palabra.Length >= 7)
                {
                    if (palabra[6].Equals(char.Parse(letraPrevia)))
                        tfLetraSiete.Text = letraPrevia;
                }

                if (palabra.Length >= 8)
                {
                    if (palabra[7].Equals(char.Parse(letraPrevia)))
                        tfLetraOcho.Text = letraPrevia;
                }

                if (palabra.Length >= 9)
                {
                    if (palabra[8].Equals(char.Parse(letraPrevia)))
                        tfLetraNueve.Text = letraPrevia;
                }
            }
            

        }

        private void ActualizarMuñeco(int erroresActuales)
        {

            if (erroresActuales == 1)
            {

                figuraCeroAhorcado.Visibility = Visibility.Collapsed;
                figuraUnoAhorcado.Visibility = Visibility.Visible;
            }
            if (erroresActuales == 2)
            {
                figuraUnoAhorcado.Visibility = Visibility.Collapsed;
                figuraDosAhorcado.Visibility = Visibility.Visible;
            }
            if (erroresActuales == 3)
            {
                figuraDosAhorcado.Visibility = Visibility.Collapsed;
                figuraTresAhorcado.Visibility = Visibility.Visible;
            }
            if (erroresActuales == 4)
            {
                figuraTresAhorcado.Visibility = Visibility.Collapsed;
                figuraCuatroAhorcado.Visibility = Visibility.Visible;
            }
            if (erroresActuales == 5)
            {
                figuraCuatroAhorcado.Visibility = Visibility.Collapsed;
                figuraCincoAhorcado.Visibility = Visibility.Visible;
            }
            if (erroresActuales == 6)
            {
                figuraCincoAhorcado.Visibility = Visibility.Collapsed;
                figuraSeisAhorcado.Visibility = Visibility.Visible;
            }
        }

        private void ComprobarDerrota()//verifica si ya perdio o gano
        {
            if (erroresPrevios == 6)
            {
                MessageBox.Show("PERDISTE");
                //codigo apra todo lo relacionado a la perdida de partida
            }
            else
            {


            }
        }

        private async void ValidarPalabraCompleta()//arma la palabra de los texbox y comprueba que este completa
        {

            if (servicio != null)
            {
                partidaRecuperada = await servicio.recuperarPartidaEjecucionAsync(infoPartida.IdPartida);

                if(partidaRecuperada!=null && !partidaRecuperada.Error)
                {
                    if (partidaRecuperada.partidaEjecucion.EstadoPartidaEjecucion.Equals("victoria"))
                    {
                        temporizador.Stop();
                        ConfigurarFinalPartida();
                        lbVictoria.Content = "GANASTE!";
                    }
                    if (partidaRecuperada.partidaEjecucion.EstadoPartidaEjecucion.Equals("derrota"))
                    {
                        temporizador.Stop();
                        ConfigurarFinalPartida();
                        ActualizarMuñeco(mensajePartidaEjecucion.partidaEjecucion.CantidadErrores+1);
                        lbVictoria.Content = "PERDISTE!";

                    }
                    if (partidaRecuperada.partidaEjecucion.EstadoPartidaEjecucion.Equals("cancelada"))
                    {
                        temporizador.Stop();
                        ConfigurarFinalPartida();
                        lbVictoria.Content = "";
                        MessageBox.Show("La partida ha sido cancelada por el otro jugador");

                        CargarPantallaSalas();
                    }
                }
                else
                {

                    ValidarPalabraCompleta();
                }

            }

        }

        private void ConfigurarFinalPartida()
        {
            btnA.IsEnabled = false;
            btnB.IsEnabled = false;
            btnC.IsEnabled = false;
            btnD.IsEnabled = false;
            btnE.IsEnabled = false;
            btnF.IsEnabled = false;
            btnG.IsEnabled = false;
            btnH.IsEnabled = false;
            btnI.IsEnabled = false;
            btnJ.IsEnabled = false;
            btnK.IsEnabled = false;
            btnL.IsEnabled = false;
            btnM.IsEnabled = false;
            btnN.IsEnabled = false;
            btnÑ.IsEnabled = false;
            btnO.IsEnabled = false;
            btnP.IsEnabled = false;
            btnQ.IsEnabled = false;
            btnR.IsEnabled = false;
            btnS.IsEnabled = false;
            btnT.IsEnabled = false;
            btnU.IsEnabled = false;
            btnV.IsEnabled = false;
            btnW.IsEnabled = false;
            btnX.IsEnabled = false;
            btnY.IsEnabled = false;
            btnZ.IsEnabled = false;
            btnFinPartida.Visibility = Visibility.Visible;
            btnCancelarpartida.Visibility = Visibility.Collapsed;
        }



        private async void ActualizarDatosPartidaEjecucion()//este metodo ya no lo utilice porque no me traia los datos
        {
            if (servicio != null)
            {
                partidaRecuperada = await servicio.recuperarPartidaEjecucionAsync(infoPartida.IdPartida);
            }
        }

        private void ClicFinPartida(object sender, RoutedEventArgs e)//boton para cuando pierde o gana la partida
        {
            RegistrarFinPartida();
            if (partidaRecuperada.partidaEjecucion.EstadoPartidaEjecucion.Equals("victoria"))
            {
                RegistrarVictoriaHistorial();
            }
                

            CargarPantallaSalas();

        }
        private async void RegistrarVictoriaHistorial()
        {
            if (servicio != null)
            {
                Mensaje mensaje = new Mensaje();
                mensaje = await servicio.RegistrarVictoriaHistorialAsync(partidaRecuperada.partidaEjecucion.IdPartida);
                if(mensaje.Error)
                {
                    RegistrarVictoriaHistorial();
                }
            }
        }
        private async void RegistrarFinPartida()
        {
            if (servicio != null)
            {
                Mensaje mensaje = new Mensaje();
                mensaje = await servicio.RegistrarFinPartidaAsync(partidaRecuperada.partidaEjecucion.IdPartida);
                if(mensaje.Error)
                {
                    RegistrarFinPartida();
                }
            }
        }

        private async void CargarPantallaSalas()
        {
            if (servicio != null)
            {
                RespuestaLogin recuperacionUsuario = await servicio.RecuperarInformacionUsuarioAsync(partidaRecuperada.partidaEjecucion.IdUsuarioDos);
                if (recuperacionUsuario.UsuarioCorrecto)
                {
                    Salas salas = new Salas();
                    salas.PasarUsuario(recuperacionUsuario.InformacionUsuario);
                    salas.Show();
                    this.Close();
                }
                else
                {
                    MessageBox.Show("Ocurrio un error al recuperar al usuario: metodo_CargarPantallaSalas_Jugador2: "+ partidaRecuperada.partidaEjecucion.IdUsuarioDos);
                }
            }
            else
            {
                MessageBox.Show("Servicio no disponible: Metodo_CargarPantallaSalas_Jugador1");
            }

        }

        private void ClicCancelarPartida(object sender, RoutedEventArgs e)
        {
            ClicCancelarPartida();

        }

        private async void ClicCancelarPartida()
        {
            temporizador.Stop();
            Mensaje respuestaCancelacion = new Mensaje();
            if (servicio != null)
            {
                respuestaCancelacion = await servicio.CancelarPartidaEjecucionAsync(partidaRecuperada.partidaEjecucion.IdPartidaEjecucion, 1, partidaRecuperada.partidaEjecucion.IdPartida);

                if (!respuestaCancelacion.Error)
                {
                    
                    MessageBox.Show("Partida Cancelada");
                    CargarPantallaSalas();
                }
            }
        }





        private void VisibilidadBotones(bool visibilidad)//para esperar la jugada del otro jugador
        {
            if (visibilidad == true)
            {
                btnA.Visibility = Visibility.Visible;
                btnB.Visibility = Visibility.Visible;
                btnC.Visibility = Visibility.Visible;
                btnD.Visibility = Visibility.Visible;
                btnE.Visibility = Visibility.Visible;
                btnF.Visibility = Visibility.Visible;
                btnG.Visibility = Visibility.Visible;
                btnH.Visibility = Visibility.Visible;
                btnI.Visibility = Visibility.Visible;
                btnJ.Visibility = Visibility.Visible;
                btnK.Visibility = Visibility.Visible;
                btnL.Visibility = Visibility.Visible;
                btnM.Visibility = Visibility.Visible;
                btnN.Visibility = Visibility.Visible;
                btnÑ.Visibility = Visibility.Visible;
                btnO.Visibility = Visibility.Visible;
                btnP.Visibility = Visibility.Visible;
                btnQ.Visibility = Visibility.Visible;
                btnR.Visibility = Visibility.Visible;
                btnS.Visibility = Visibility.Visible;
                btnT.Visibility = Visibility.Visible;
                btnU.Visibility = Visibility.Visible;
                btnV.Visibility = Visibility.Visible;
                btnW.Visibility = Visibility.Visible;
                btnX.Visibility = Visibility.Visible;
                btnY.Visibility = Visibility.Visible;
                btnZ.Visibility = Visibility.Visible;
                btnCancelarpartida.Visibility = Visibility.Visible;
            }
            else
            {
                btnA.Visibility = Visibility.Collapsed;
                btnB.Visibility = Visibility.Collapsed;
                btnC.Visibility = Visibility.Collapsed;
                btnD.Visibility = Visibility.Collapsed;
                btnE.Visibility = Visibility.Collapsed;
                btnF.Visibility = Visibility.Collapsed;
                btnG.Visibility = Visibility.Collapsed;
                btnH.Visibility = Visibility.Collapsed;
                btnI.Visibility = Visibility.Collapsed;
                btnJ.Visibility = Visibility.Collapsed;
                btnK.Visibility = Visibility.Collapsed;
                btnL.Visibility = Visibility.Collapsed;
                btnM.Visibility = Visibility.Collapsed;
                btnN.Visibility = Visibility.Collapsed;
                btnÑ.Visibility = Visibility.Collapsed;
                btnO.Visibility = Visibility.Collapsed;
                btnP.Visibility = Visibility.Collapsed;
                btnQ.Visibility = Visibility.Collapsed;
                btnR.Visibility = Visibility.Collapsed;
                btnS.Visibility = Visibility.Collapsed;
                btnT.Visibility = Visibility.Collapsed;
                btnU.Visibility = Visibility.Collapsed;
                btnV.Visibility = Visibility.Collapsed;
                btnW.Visibility = Visibility.Collapsed;
                btnX.Visibility = Visibility.Collapsed;
                btnY.Visibility = Visibility.Collapsed;
                btnZ.Visibility = Visibility.Collapsed;
               // btnCancelarpartida.Visibility = Visibility.Collapsed;
            }

        }

        private MensajePartidaEjecucion mensajePartidaEjecucion = new MensajePartidaEjecucion();

        public async void VerificarTurnoJugador()////////////////
        {
            if (servicio != null)
            {

                mensajePartidaEjecucion = await servicio.recuperarPartidaEjecucionAsync(partidaRecuperada.partidaEjecucion.IdPartida);//aveces msarca error de instancia tras un timepo en ejecucion sin que yo haga nada
                if (mensajePartidaEjecucion != null && mensajePartidaEjecucion.partidaEjecucion != null && mensajePartidaEjecucion.partidaEjecucion.TurnoJugador != null && mensajePartidaEjecucion.partidaEjecucion.TurnoJugador == 2|| mensajePartidaEjecucion.partidaEjecucion.EstadoPartidaEjecucion.Equals("cancelada"))//turno del jugador uno para jugar
                {

                    AnalizarRespuesta();
                    
                }
              
            }



        }


    }
}
