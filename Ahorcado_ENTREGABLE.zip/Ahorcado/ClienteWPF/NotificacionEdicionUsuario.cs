﻿using ServiceReference1;

namespace ClienteWPF
{
    public interface NotificacionEdicionUsuario
    {
        void actualizarUsuario(Usuario usuarioEditado);
    }
}
