﻿using ServiceReference1;
using System;
using System.Collections.ObjectModel;
using System.Windows;
using System.Windows.Controls;
//using ServiceReference1;
namespace ClienteWPF
{

    public partial class SeleccionPalabra : Window
    {
        public ObservableCollection<string> categorias = new ObservableCollection<String>();
        public ObservableCollection<string> palabrasC = new ObservableCollection<String>();
        private MensajeRecuperacionPalabras palabrasCB;
        private ServicioJuegoClient servicio;
        private Usuario usuarioUno;



        public SeleccionPalabra()
        {
            servicio = new ServicioJuegoClient();
            InitializeComponent();
            CargarCategorias();

        }



        private async void CargarCategorias()
        {
            if (servicio != null)
            {
                palabrasCB = await servicio.RecuperarPalabrasAsync();
                if (!palabrasCB.Error)
                {
                    foreach (Palabra aux in palabrasCB.Palabras)
                    {
                        if (!categorias.Contains(aux.NombreCategoria))
                        {
                            categorias.Add(aux.NombreCategoria);
                        }

                    }
                    cbCategoria.ItemsSource = categorias;
                }
            }
        }

        private void clicCancelar(object sender, RoutedEventArgs e)
        {
            Salas salas = new Salas();
            salas.PasarUsuario(usuarioUno);
            salas.Show();
            this.Close();

        }



        private void ClicCrearPartida(object sender, RoutedEventArgs e)
        {
            if (cbPalabra.SelectedIndex != -1)
            {
                CrearPartida();

            }
            else
            {
                MessageBox.Show("Selecciona la palabra deseada para crear una partida");
            }
        }

        private async void CrearPartida()
        {
            Partida partida = new Partida();
            partida.FechaCreacion = DateTime.Now.ToString("dd/MM/yyyy");
            partida.EstadoPartida = "En Espera";
            partida.IdUsuarioUno = usuarioUno.IdUsuario;
            foreach (Palabra palabraAux in palabrasCB.Palabras)
            {
                if (palabraAux.PalabraNombre.Equals(cbPalabra.Text))
                    partida.IdPalabra = palabraAux.IdPalabra;
            }
            Mensaje mensajeCreacion = await servicio.CrearPartidaAsync(partida);

            if (mensajeCreacion.Error)
            {
                MessageBox.Show(mensajeCreacion.MensajeRespuesta);
                this.Close();
            }
            else
            {
                MensajePartida partidaRecuperada = await servicio.RecuperaInfoPartidaAsync(usuarioUno.IdUsuario);


                CargarPantallaEspera(partidaRecuperada);
            }

        }


        private void CargarPantallaEspera(MensajePartida partidaRecuperada)
        {
            Espera stage = new Espera();

            stage.DatosPartida(partidaRecuperada);

            stage.Show();
            this.Close();
        }

        public void PasarValor(Usuario usuarioUno)//para cargar el correo a la partida
        {
            this.usuarioUno = usuarioUno;
        }

        private void CategoriaSeleccionada(object sender, SelectionChangedEventArgs e)//listener de cbCategoria
        {

            cbPalabra.ItemsSource = null;
            lbDescripcion.Content = "Descripcion";

            string categoriaSeleccionada = cbCategoria.SelectedItem.ToString();
            palabrasC.Clear();
            foreach (Palabra palabra in palabrasCB.Palabras)
            {
                if (palabra.NombreCategoria.Equals(categoriaSeleccionada))
                {
                    palabrasC.Add(palabra.PalabraNombre);
                }
            }
            cbPalabra.ItemsSource = palabrasC;

        }

        private void PalabraSeleccionada(object sender, SelectionChangedEventArgs e)
        {
            if (cbPalabra.SelectedIndex != -1)
            {
                if (cbCategoria.SelectedIndex != -1)
                {
                    foreach (Palabra aux in palabrasCB.Palabras)
                    {
                        if (aux.PalabraNombre.Equals(cbPalabra.SelectedItem.ToString()))
                        {
                            lbDescripcion.Content = aux.Descripcion;
                        }
                    }
                }
            }

        }
    }
}
