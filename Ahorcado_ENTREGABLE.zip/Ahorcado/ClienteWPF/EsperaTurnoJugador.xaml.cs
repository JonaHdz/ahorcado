﻿using ServiceReference1;
using System;
using System.Windows;
using System.Windows.Threading;

namespace ClienteWPF
{
    /// <summary>
    /// Lógica de interacción para EsperaTurnoJugador.xaml
    /// </summary>
    public partial class EsperaTurnoJugador : Window
    {
        private DispatcherTimer temporizador;
        private ServicioJuegoClient servicio;
        private MensajePartidaEjecucion mensajePartidaEjecucion = new MensajePartidaEjecucion();
        private Partida partida;
        int turnoJugador;
        private NotificacionJugada notificacion;
        public EsperaTurnoJugador(Partida partida, int turnoJugador, NotificacionJugada notificacion)
        {

            InitializeComponent();
            this.notificacion = notificacion;
            this.turnoJugador = turnoJugador;
            servicio = new ServicioJuegoClient();
            this.partida = partida;
            temporizador = new DispatcherTimer();
            temporizador.Interval = new TimeSpan(0, 0, 0, 3);//cada  segundo
            temporizador.Tick += (a, b) =>
            {

                 VerificarTurnoJugador();

            };
            temporizador.Start();
        }

        public async void VerificarTurnoJugador()////////////////
        {
            if (servicio != null)
            {
                // if (mensajePartidaEjecucion !=null&& mensajePartidaEjecucion.partidaEjecucion!=null && mensajePartidaEjecucion.partidaEjecucion.TurnoJugador!=null && mensajePartidaEjecucion.partidaEjecucion.TurnoJugador == turnoJugador)//turno del jugador uno para jugar

                mensajePartidaEjecucion = await servicio.recuperarPartidaEjecucionAsync(partida.IdPartida);//aveces msarca error de instancia tras un timepo en ejecucion sin que yo haga nada
                if (mensajePartidaEjecucion != null && mensajePartidaEjecucion.partidaEjecucion != null && mensajePartidaEjecucion.partidaEjecucion.TurnoJugador != null && mensajePartidaEjecucion.partidaEjecucion.TurnoJugador == turnoJugador)//turno del jugador uno para jugar
                {//podria agregar una comprobacion de que no sea null antes dea condicion de arriba
                    temporizador.Stop();
                   // MessageBox.Show("temporizador parado");
                    notificacion.AnalizarRespuesta();
                    this.Close();
                }
                else
                {
                    //  MessageBox.Show("el objeto usado en la pantalla EsperatUrnoJugador es null o tienealgun error");
                }
            }



        }

    }
}
