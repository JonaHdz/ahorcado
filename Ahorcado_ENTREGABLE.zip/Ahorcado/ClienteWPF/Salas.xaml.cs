﻿using ServiceReference1;
using System.Windows;

namespace ClienteWPF
{

    public partial class Salas : Window, NotificacionEdicionUsuario
    {
        private ServicioJuegoClient servicio;
        Usuario usuarioIngresado = new Usuario();
        private MensajeRecuperacionPartidas partidasRecuperadas = new MensajeRecuperacionPartidas();
        public Salas()
        {
            InitializeComponent();
            servicio = new ServicioJuegoClient();
            CargarPartidas();
        }


        private async void CargarPartidas()
        {
            if (servicio != null)
            {
                partidasRecuperadas = await servicio.recuperarPartidasAsync();
                dgLista.ItemsSource = partidasRecuperadas.Partidas;

            }

        }

        private void ClicCerrarSesion(object sender, RoutedEventArgs e)
        {
            MainWindow stage = new MainWindow();
            stage.Show();
            this.Close();
        }

        private void ClicHistorialPartidas(object sender, RoutedEventArgs e)
        {
            Historialpartidas stage = new Historialpartidas(usuarioIngresado);
            stage.ShowDialog();

        }

        public void PasarUsuario(Usuario usuarioIngresado)
        {
            this.usuarioIngresado = usuarioIngresado;
        }

        private void ClicEditar(object sender, RoutedEventArgs e)
        {
            FormularioRegistroUsuario stage = new FormularioRegistroUsuario();
            stage.IniciarValores(true, usuarioIngresado, this);
            stage.Show();
        }

        public void actualizarUsuario(Usuario usuarioEditado) //Implementación de interfaz
        {
            this.usuarioIngresado = usuarioEditado;
        }

        private void ClicCrearPartida(object sender, RoutedEventArgs e)
        {
            SeleccionPalabra stage = new SeleccionPalabra();
            stage.PasarValor(usuarioIngresado);

            stage.Show();
            this.Close();
        }


        private void ClicUnirsePartida(object sender, RoutedEventArgs e)
        {
            int filaSeleccionada = dgLista.SelectedIndex;
            if (filaSeleccionada == -1)
            {
                MessageBox.Show("Para unirte a una partida, selecciona una o actualiza la lista");

            }
            else
            {

                IngresarPartida(filaSeleccionada);
            }
        }

        //por logica del negocio, un usuario solo puede crear una partida a la vez, por lo que no habra datos repetidos en el dataGrid
        private async void IngresarPartida(int fila)
        {
            Partida partida = partidasRecuperadas.Partidas[fila];
            if (servicio != null)
            {
                Mensaje mensaje = await servicio.RegistrarUsuarioDosAsync(usuarioIngresado, partida.IdPartida);

                if (!mensaje.Error)
                {
                    EntrarJuego(fila);
                }
                else
                {
                    MessageBox.Show("La partida seleccionada ya no se encuentra disponible");
                    CargarPartidas();
                }
            }
        }

        private async void EntrarJuego(int fila)
        {
            Partida partida = partidasRecuperadas.Partidas[dgLista.SelectedIndex];

            MensajePartida partidaRecuperada = await servicio.RecuperaInfoPartidaAsync(partida.IdUsuarioUno);
            CrearTablaJuegoEjecucion(partida.IdPartida);
            Jugador2 stageJugador2 = new Jugador2();
            stageJugador2.CargarDatosPartida(partidaRecuperada);
            stageJugador2.DeshabilitarEdicionCampos();

            stageJugador2.Show();
            this.Close();
        }

        private async void CrearTablaJuegoEjecucion(int idPartida)
        {
            if (servicio != null)
            {
                Mensaje mensaje = await servicio.CrearPArtidaEjecucionAsync(idPartida, 0, 2);
            }
        }

        private void ClicActualizarPartidas(object sender, RoutedEventArgs e)
        {
            CargarPartidas();
        }
    }
}
