﻿using ServiceReference1;
using System;
using System.Windows;
using System.Windows.Threading;

namespace ClienteWPF
{

    public partial class Espera : Window
    {
        private DispatcherTimer temporizador;
        private ServicioJuegoClient servicio;
        private MensajePartida datosPartida;
        public Espera()
        {
            InitializeComponent();
            servicio = new ServicioJuegoClient();
            // EntradaSegundoJugador();

            temporizador = new DispatcherTimer();
            temporizador.Interval = new TimeSpan(0, 0, 0, 3);
            temporizador.Tick += (a, b) =>
             {
                 busquedaSegundoJugador();
             };
            temporizador.Start();
        }



        private void cargarPantallaJugadorUno(MensajePartida partida)
        {

            Jugador1 stageJugador = new Jugador1();
            stageJugador.CargarDatosPartida(partida.Partida);
            stageJugador.DeshabilitarCamposNoUsados();
            this.Close();
            stageJugador.Show();


        }



        private void ClicCancelarPartida(object sender, RoutedEventArgs e)
        {
            CancelarPartida();
        }//obtiene los datos de la pantalla anterior

        public void DatosPartida(MensajePartida datosPartida)
        {
            this.datosPartida = datosPartida;
        }

        private async void CancelarPartida()
        {
            if (servicio != null)
            {
                temporizador.Stop();
                Mensaje mensajeCancelacion = await servicio.EliminarPartidaAsync(datosPartida.Partida.IdPartida);
                if (mensajeCancelacion != null || mensajeCancelacion.Error == false)
                {
                    Salas salas = new Salas();
                    RespuestaLogin respuesta = await servicio.RecuperarInformacionUsuarioAsync(datosPartida.Partida.IdUsuarioUno);
                    salas.PasarUsuario(respuesta.InformacionUsuario);
                    salas.Show();
                    this.Close();
                }
                else
                    CancelarPartida();

            }

        }


        private async void busquedaSegundoJugador()
        {
            if (servicio != null)
            {
                MensajePartida respuesta = new MensajePartida();
                respuesta = await servicio.RecuperaInfoPartidaAsync(datosPartida.Partida.IdUsuarioUno);
                if (respuesta.Partida != null && respuesta.Partida.IdUsuarioDos != 0)//if (respuesta.Partida.IdUsuarioDos != 0 && respuesta.Partida.IdUsuarioDos!=null)
                {
                    temporizador.Stop();
                    // MessageBox.Show("Un jugador ha ingresado a tu partida :" + respuesta.Partida.IdPartida);
                    cargarPantallaJugadorUno(respuesta);

                }
            }
            else
            {
                MessageBox.Show("El servicio no se encuentra disponible");
            }
        }
    }//class
}//namespace
