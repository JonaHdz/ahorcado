﻿namespace ClienteWPF
{
    public interface NotificacionJugada
    {
        void AnalizarRespuesta();//avisa al jugador dos que el jugador uno ha revisado
                                 //la letra introducida,y verifica si fue correcta o no
    }
}
