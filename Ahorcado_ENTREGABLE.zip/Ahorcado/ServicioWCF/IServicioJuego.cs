﻿using ServicioWCF.Modelo.Dao;
using ServicioWCF.Modelo.Poco;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Runtime.Serialization;
using System.ServiceModel;
using System.Text;

namespace ServicioWCF
{
    // NOTA: puede usar el comando "Rename" del menú "Refactorizar" para cambiar el nombre de interfaz "IServicioJuego" en el código y en el archivo de configuración a la vez.
    [ServiceContract]
    public interface IServicioJuego
    {
        [OperationContract]
        RespuestaLogin ValidarUsuario(string correo, string passowrd);

        [OperationContract]
        Mensaje RegistrarUsuario(Usuario usuario);

        [OperationContract]
        RespuestaLogin ActualizarUsuario(Usuario usuario);

        [OperationContract]
        MensajeRecuperacionPalabras RecuperarPalabras();

        [OperationContract]
        Mensaje CrearPartida(Partida partida);

        [OperationContract]
        MensajePartida RecuperaInfoPartida(int idUsuarioUno);
        [OperationContract]
        Mensaje EliminarPartida(int idPartida);

        [OperationContract]
        MensajeRecuperacionPartidas recuperarPartidas();
        [OperationContract]
        Mensaje RegistrarUsuarioDos(Usuario usuario, int idPartida);

        [OperationContract]
        MensajePartida EsperaJugadorUno(int idUsuarioUno);
        [OperationContract]
        Mensaje EliminarPartidasResiduales(int idUsuario);
        [OperationContract]
        RespuestaLogin RecuperarInformacionUsuario(int idUsuario);
        [OperationContract]
        Mensaje CrearPArtidaEjecucion(int idPartida, int errores, int turnoJugador);
        [OperationContract]
        MensajePartidaEjecucion recuperarPartidaEjecucion(int idPartida);
        [OperationContract]
        Mensaje RegistrarJugadaJugadorDos(int turnoJugador, string letra, int idPartidaEjecucion);
        [OperationContract]
        Mensaje RegistrarJugadaEquivocada(int turnoJugador, int cantidadErrores,int idpartidaEjecucion);

        [OperationContract]
        Mensaje RegistrarFinPartidaEjecucion(int idPartidaEjecucion,Boolean estadoganador);
        [OperationContract]
        Mensaje RegistrarFinPartida(int idPartida);
        [OperationContract]
        Mensaje RegistrarVictoriaHistorial(int idPartida);
        [OperationContract]
        MensajePartida RecuperarPartidaEspera(int idUsuario);

        [OperationContract]
        MensajeHistorialPartida RecuperarHistorialpartidas(int idUsuario);

        [OperationContract]
        Mensaje CancelarPartidaEjecucion(int idPartidaEjecucion,int turnoJugador, int idPartida);

    }
}
