﻿using MySql.Data.MySqlClient;
using ServicioWCF.Modelo.Poco;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace ServicioWCF.Modelo.Dao
{
    public class PalabraDao
    {
        public static MensajeRecuperacionPalabras ObtenerPalabras()
        {
            MensajeRecuperacionPalabras mensaje = new MensajeRecuperacionPalabras();
            List<Palabra> palabrasBD = new List<Palabra>();
            MySqlConnection conexionBD = ConnectionUtil.obtenerConexion();
            if (conexionBD != null)
            {
                try
                {
                    string consulta = string.Format("SELECT * from Palabras p inner join categorias c on p.categoria_idCategoria = c.idcategoria");
                    MySqlCommand mySqlCommand = new MySqlCommand(consulta, conexionBD);
                    MySqlDataReader respuestaBD = mySqlCommand.ExecuteReader();
                    while (respuestaBD.Read())
                    {

                        Palabra palabra = new Palabra();
                     

                        palabra.IdPalabra = ((respuestaBD.IsDBNull(0)) ? 0 : respuestaBD.GetInt32(0));
                        palabra.PalabraNombre = ((respuestaBD.IsDBNull(1)) ? "" : respuestaBD.GetString(1));
                        palabra.Descripcion = ((respuestaBD.IsDBNull(2)) ? "" : respuestaBD.GetString(2));
                        palabra.Categoria_idCategoria = ((respuestaBD.IsDBNull(3)) ? 0 : respuestaBD.GetInt32(3));
                        palabra.IdCategoria = ((respuestaBD.IsDBNull(4)) ? 0 : respuestaBD.GetInt32(4));
                        palabra.NombreCategoria= ((respuestaBD.IsDBNull(5)) ? "" : respuestaBD.GetString(5));

                        palabrasBD.Add(palabra);
                        //respuestaBD.NextResult();
                    }
                    mensaje.Palabras = palabrasBD;
                    mensaje.Error = false;
                    mensaje.Mensaje = "INFORMACION RECUPERADA";
                }
                catch (Exception ex)
                {
                    conexionBD.Close();
                    mensaje.Error = true;
                    mensaje.Mensaje = "ERROR AL RECUPERAR INFORMACION DE LA BASE DE DATOS: " +ex.Message;
                }
            }
            else//error al conectar
            {
                mensaje.Error = true;
                mensaje.Mensaje = "ERROR AL CONECTAR CON LA BASE DE DATOS";

            }
            conexionBD.Close();

            return mensaje;
        }

    }
}