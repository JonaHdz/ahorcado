﻿using MySql.Data.MySqlClient;
using ServicioWCF.Modelo.Poco;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace ServicioWCF.Modelo.Dao
{
    public class UsuarioDao
    {
        public static RespuestaLogin verificarUsuario(string correo,
                                              string password)
        {
            RespuestaLogin respuesta = new RespuestaLogin();
            MySqlConnection conexionBD = ConnectionUtil.obtenerConexion();
            if (conexionBD != null)
            {
                try
                {
                    string consulta = string.Format("SELECT * FROM usuario " +
                                                "WHERE correo = '{0}' AND " +
                                                "password = '{1}'", correo, password);
                    MySqlCommand mySqlCommand = new MySqlCommand(consulta, conexionBD);
                    MySqlDataReader respuestaBD = mySqlCommand.ExecuteReader();
                    if (respuestaBD.Read())
                    {
                        respuesta.UsuarioCorrecto = true;
                        respuesta.Mensaje = "Usuario verificado correctamente";
                        Usuario usuario = new Usuario();
                        usuario.IdUsuario = ((respuestaBD.IsDBNull(0)) ? 0 : respuestaBD.GetInt32(0));
                        usuario.NombreCompleto = ((respuestaBD.IsDBNull(1)) ? "" : respuestaBD.GetString(1));
                        usuario.FechaNacimiento = (respuestaBD.IsDBNull(2) ? "" : respuestaBD.GetString(2));
                        usuario.Telefono = ((respuestaBD.IsDBNull(3)) ? "" : respuestaBD.GetString(3));
                        usuario.Password = ((respuestaBD.IsDBNull(4)) ? "" : respuestaBD.GetString(4));
                        usuario.Correo = ((respuestaBD.IsDBNull(5)) ? "" : respuestaBD.GetString(5));
                        respuesta.InformacionUsuario = usuario;
                    }
                    else
                    {
                        conexionBD.Close();
                        respuesta.UsuarioCorrecto = false;
                        respuesta.Mensaje = "Usuario y/o contraseña incorrectos...";
                    }
                }
                catch (Exception ex)
                {
                    conexionBD.Close();
                    respuesta.UsuarioCorrecto = false;
                    respuesta.Mensaje = ex.Message;
                }
            }
            else
            {
                respuesta.UsuarioCorrecto = false;
                respuesta.Mensaje = "Por el momento no hay servicio disponible...";
            }
            conexionBD.Close();
            return respuesta;
        }

        public static Mensaje insertarUsuario(Usuario usuarioRegistro)//agregar un validacion para ver si no exite un usuario con el mismo correo
        {
            Mensaje mensaje = new Mensaje();
            MySqlConnection conexionBD = ConnectionUtil.obtenerConexion();
            if (conexionBD != null)
            {
                try
                {
                    string sentencia = "INSERT INTO usuario (nombreCompleto, fechaNacimiento, telefono, password, correo) " +
                                       "VALUES(@nombre,@fecha,@telefono,@password,@correo)";
                    MySqlCommand mySqlCommand = new MySqlCommand(sentencia, conexionBD);
                    mySqlCommand.Parameters.AddWithValue("@nombre", usuarioRegistro.NombreCompleto);
                    mySqlCommand.Parameters.AddWithValue("@fecha", usuarioRegistro.FechaNacimiento);
                    mySqlCommand.Parameters.AddWithValue("@telefono", usuarioRegistro.Telefono);
                    mySqlCommand.Parameters.AddWithValue("@password", usuarioRegistro.Password);
                    mySqlCommand.Parameters.AddWithValue("@correo", usuarioRegistro.Correo);
                    mySqlCommand.Prepare();
                    int filasAfectadas = mySqlCommand.ExecuteNonQuery();
                    if (filasAfectadas > 0)
                    {
                        conexionBD.Close();
                        mensaje.Error = false;
                        mensaje.MensajeRespuesta = "Usuario registrado con éxito";
                    }
                    else
                    {
                        conexionBD.Close();
                        mensaje.Error = true;
                        mensaje.MensajeRespuesta = "Error al registrar el usuario";
                    }

                }
                catch (Exception ex)
                {
                    conexionBD.Close();
                    mensaje.Error = true;
                    mensaje.MensajeRespuesta = ex.Message;
                }
            }
            else
            {
                conexionBD.Close();
                mensaje.Error = true;
                mensaje.MensajeRespuesta = "Por el momento no hay conexión con los servicios...";
            }
            conexionBD.Close();
            return mensaje;
        }

        public static RespuestaLogin ActualizarUsuario(Usuario usuarioRegistro)
        {
            RespuestaLogin mensaje = new RespuestaLogin();
            MySqlConnection conexionBD = ConnectionUtil.obtenerConexion();
            if (conexionBD != null)
            {
                try//no le paso el username
                {
                    string sentencia = "UPDATE usuario SET nombreCompleto = @nombre,fechaNacimiento = @fechaNacimiento,telefono=@telefono,password = @password, correo = @correo WHERE idUsuario = @idUsuario";
                    MySqlCommand mySqlCommand = new MySqlCommand(sentencia, conexionBD);
                    mySqlCommand.Parameters.AddWithValue("@nombre", usuarioRegistro.NombreCompleto);
                    mySqlCommand.Parameters.AddWithValue("@fechaNacimiento", usuarioRegistro.FechaNacimiento);
                    mySqlCommand.Parameters.AddWithValue("@telefono", usuarioRegistro.Telefono);
                    mySqlCommand.Parameters.AddWithValue("@password", usuarioRegistro.Password);
                    mySqlCommand.Parameters.AddWithValue("@correo", usuarioRegistro.Correo);
                    mySqlCommand.Parameters.AddWithValue("@idUsuario", usuarioRegistro.IdUsuario);
                    mySqlCommand.Prepare();
                    int filasAfectadas = mySqlCommand.ExecuteNonQuery();
                    if (filasAfectadas > 0)
                    {
                        
                        mensaje.UsuarioCorrecto = false;
                        mensaje.Mensaje = "Usuario actualizado con éxito";
                    }
                    else
                    {
                        mensaje.UsuarioCorrecto = true;
                        mensaje.Mensaje = "Error al actualizar el usuario";
                    }

                }
                catch (Exception ex)
                {
                    conexionBD.Close();
                    mensaje.UsuarioCorrecto = true;
                    mensaje.Mensaje = ex.Message;
                }
            }
            else
            {
                conexionBD.Close();
                mensaje.UsuarioCorrecto = true;
                mensaje.Mensaje = "Por el momento no hay conexión con los servicios...";
            }
            conexionBD.Close();
            return mensaje;
        }

        public static RespuestaLogin RecuperarInformacionUsuario(int idUsuario)
        {
            RespuestaLogin respuesta = new RespuestaLogin();
            MySqlConnection conexionBD = ConnectionUtil.obtenerConexion();
            if (conexionBD != null)
            {
                try
                {
                    string consulta = string.Format("SELECT * FROM usuario " +
                                                "WHERE idUsuario = @idUsuario");
                    MySqlCommand mySqlCommand = new MySqlCommand(consulta, conexionBD);
                    mySqlCommand.Parameters.AddWithValue("@idUsuario", idUsuario);
                    MySqlDataReader respuestaBD = mySqlCommand.ExecuteReader();
                    if (respuestaBD.Read())
                    {
                        respuesta.UsuarioCorrecto = true;
                        respuesta.Mensaje = "Usuario recuperado correctamente";
                        Usuario usuario = new Usuario();
                        usuario.IdUsuario = ((respuestaBD.IsDBNull(0)) ? 0 : respuestaBD.GetInt32(0));
                        usuario.NombreCompleto = ((respuestaBD.IsDBNull(1)) ? "" : respuestaBD.GetString(1));
                        usuario.FechaNacimiento = (respuestaBD.IsDBNull(2) ? "" : respuestaBD.GetString(2));
                        usuario.Telefono = ((respuestaBD.IsDBNull(3)) ? "" : respuestaBD.GetString(3));
                        usuario.Password = ((respuestaBD.IsDBNull(4)) ? "" : respuestaBD.GetString(4));
                        usuario.Correo = ((respuestaBD.IsDBNull(5)) ? "" : respuestaBD.GetString(4));
                        respuesta.InformacionUsuario = usuario;
                    }
                    else
                    {
                        conexionBD.Close();
                        respuesta.UsuarioCorrecto = false;
                        respuesta.Mensaje = "usuario no recuperado o no encontrado";
                    }
                }
                catch (Exception ex)
                {
                    conexionBD.Close();
                    respuesta.UsuarioCorrecto = false;
                    respuesta.Mensaje = ex.Message;
                }
            }
            else
            {
                conexionBD.Close();
                respuesta.UsuarioCorrecto = false;
                respuesta.Mensaje = "Por el momento no hay servicio disponible...";
            }
            conexionBD.Close();
            return respuesta;
        }

        public static RespuestaLogin RecuperarCorreo(string correo)
        {
            RespuestaLogin respuesta = new RespuestaLogin();
            MySqlConnection conexionBD = ConnectionUtil.obtenerConexion();
            if (conexionBD != null)
            {
                try
                {
                    string consulta = string.Format("SELECT correo from usuario where correo=@correo;");
                    MySqlCommand mySqlCommand = new MySqlCommand(consulta, conexionBD);
                    mySqlCommand.Parameters.AddWithValue("@correo", correo);
                    MySqlDataReader respuestaBD = mySqlCommand.ExecuteReader();
                    if (respuestaBD.Read())
                    {
                        respuesta.UsuarioCorrecto = false;
                        respuesta.Mensaje = "El correo ya fue usado";
                        //Usuario usuario = new Usuario();
                        //  usuario.Correo = ((respuestaBD.IsDBNull(0)) ? "" : respuestaBD.GetString(0));

                        // respuesta.InformacionUsuario = usuario;
                    }
                    else
                    {
                        conexionBD.Close();
                        respuesta.UsuarioCorrecto = true;
                        respuesta.Mensaje = "Correo valido";
                    }
                }
                catch (Exception ex)
                {
                    conexionBD.Close();
                    respuesta.UsuarioCorrecto = false;
                    respuesta.Mensaje = ex.Message;
                }
            }
            else
            {
                conexionBD.Close();
                respuesta.UsuarioCorrecto = false;
                respuesta.Mensaje = "Por el momento no hay servicio disponible...";
            }
            conexionBD.Close();
            return respuesta;
        }


    }//class
}//namespace