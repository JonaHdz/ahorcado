﻿using MySql.Data.MySqlClient;
using ServicioWCF.Modelo.Poco;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace ServicioWCF.Modelo.Dao
{
    public class PartidaDao
    {
        
        public static Mensaje RegistrarpartidaNueva(Partida partidaCreacion)
        {
           
            Mensaje mensaje = new Mensaje();
            MySqlConnection conexionBD = ConnectionUtil.obtenerConexion();
            if (conexionBD != null )
            {
                try
                {
                    string sentencia = "INSERT INTO partida (fechaCreacion,estadoPartida,Palabra_idPalabra1,idUsuarioUno) " +
                                       "VALUES(@fechaCreacion,@estadoPartida,@palabra_idPalabra1,@idUsuarioUno)";
                    MySqlCommand mySqlCommand = new MySqlCommand(sentencia, conexionBD);
                    mySqlCommand.Parameters.AddWithValue("@fechaCreacion", partidaCreacion.FechaCreacion);
                    mySqlCommand.Parameters.AddWithValue("@estadoPartida", partidaCreacion.EstadoPartida);
                    mySqlCommand.Parameters.AddWithValue("@palabra_idPalabra1", partidaCreacion.IdPalabra);
                    mySqlCommand.Parameters.AddWithValue("@idUsuarioUno", partidaCreacion.IdUsuarioUno);
                    //mySqlCommand.Parameters.AddWithValue("@idUsuarioDos", partidaCreacion.UsuarioRetador.IdUsuario);
                    mySqlCommand.Prepare();
                    int filasAfectadas = mySqlCommand.ExecuteNonQuery();
                    if (filasAfectadas > 0)
                    {
                        conexionBD.Close();
                        mensaje.Error = false;
                        mensaje.MensajeRespuesta = "Partida registrada con exito";
                    }
                    else
                    {
                        mensaje.Error = true;
                        mensaje.MensajeRespuesta = "Error al registrar la aprtida en sistema";
                        conexionBD.Close();
                    }

                }
                catch (Exception ex)
                {
                    mensaje.Error = true;
                    mensaje.MensajeRespuesta = ex.Message;
                    conexionBD.Close();
                }
            }
            else
            {
                mensaje.Error = true;
                mensaje.MensajeRespuesta = "Por el momento no hay conexión con los servicios...";
                conexionBD.Close();
            }
            return mensaje;
        }

        public static MensajePartida ObtenerPartida(int idUsuarioUno)
        {
            MensajePartida mensajeRecuperacion = new MensajePartida();
            MySqlConnection conexionBD = ConnectionUtil.obtenerConexion();
            if (conexionBD != null)
            {
                try
                {
                    string consulta = string.Format("select * from partida where idUsuarioUno=@idUsuarioUno" );
                    MySqlCommand mySqlCommand = new MySqlCommand(consulta, conexionBD);
                    mySqlCommand.Parameters.AddWithValue("@idUsuarioUno", idUsuarioUno);
                    MySqlDataReader respuestaBD = mySqlCommand.ExecuteReader();
                    while (respuestaBD.Read())
                    {
                        Partida partida = new Partida();


                        partida.IdPartida = ((respuestaBD.IsDBNull(0)) ? 0 : respuestaBD.GetInt32(0));
                        partida.FechaCreacion = ((respuestaBD.IsDBNull(1)) ? "" : respuestaBD.GetString(1));
                        partida.EstadoPartida = (respuestaBD.IsDBNull(2) ? "" : respuestaBD.GetString(2));
                        partida.IdPalabra = ((respuestaBD.IsDBNull(3)) ? 0 : respuestaBD.GetInt32(3));
                        partida.IdUsuarioUno = ((respuestaBD.IsDBNull(4)) ? 0 : respuestaBD.GetInt32(4));
                        partida.IdUsuarioDos = ((respuestaBD.IsDBNull(5)) ? 0 : respuestaBD.GetInt32(5));
                        mensajeRecuperacion.Error = false;
                        mensajeRecuperacion.Partida = partida;
                        mensajeRecuperacion.Mensaje = "Partida recuperada exitosamente";
                        //DUDA:por que marca error si le paso directamente los datos a mensajeRecuperacion.Partida, y no al pasar a una instancia aparte y despues pasarsela a mensajeRecuperacion
                    }
                }
                catch (Exception ex)
                {
                    mensajeRecuperacion.Error = true;
                    mensajeRecuperacion.Mensaje = "Ocurrio un error al recuperar la informacion de la partida para su cancelacion: "+ex.Message;
                    conexionBD.Close();
                }
            }

            conexionBD.Close();
            return mensajeRecuperacion;
        }

        public static MensajePartida ObtenerPartidaEspera(int idUsuarioUno)
        {
            MensajePartida mensajeRecuperacion = new MensajePartida();
            MySqlConnection conexionBD = ConnectionUtil.obtenerConexion();
            if (conexionBD != null)
            {
                try
                {
                    string consulta = string.Format("select * from partida where idUsuarioUno=@idUsuarioUno and idUsuarioDos is null");
                    MySqlCommand mySqlCommand = new MySqlCommand(consulta, conexionBD);
                    mySqlCommand.Parameters.AddWithValue("@idUsuarioUno", idUsuarioUno);
                    MySqlDataReader respuestaBD = mySqlCommand.ExecuteReader();
                    if (respuestaBD.Read())
                    {
                        Partida partida = new Partida();


                        partida.IdPartida = ((respuestaBD.IsDBNull(0)) ? 0 : respuestaBD.GetInt32(0));
                        partida.FechaCreacion = ((respuestaBD.IsDBNull(1)) ? "" : respuestaBD.GetString(1));
                        partida.EstadoPartida = (respuestaBD.IsDBNull(2) ? "" : respuestaBD.GetString(2));
                        partida.IdPalabra = ((respuestaBD.IsDBNull(3)) ? 0 : respuestaBD.GetInt32(3));
                        partida.IdUsuarioUno = ((respuestaBD.IsDBNull(4)) ? 0 : respuestaBD.GetInt32(4));
                        partida.IdUsuarioDos = ((respuestaBD.IsDBNull(5)) ? 0 : respuestaBD.GetInt32(5));
                        mensajeRecuperacion.Error = false;
                        mensajeRecuperacion.Partida = partida;
                        mensajeRecuperacion.Mensaje = "Partida en espera recuperada exitosamente";
                        //DUDA:por que marca error si le paso directamente los datos a mensajeRecuperacion.Partida, y no al pasar a una instancia aparte y despues pasarsela a mensajeRecuperacion
                    }
                }
                catch (Exception ex)
                {
                    mensajeRecuperacion.Error = true;
                    mensajeRecuperacion.Mensaje = "Servicio no disponible: " + ex.Message;
                    conexionBD.Close();
                }
            }
            conexionBD.Close();
            return mensajeRecuperacion;
        }


            public static Mensaje EliminarPartida(int idPartida)
        {
            Mensaje mensaje = new Mensaje();
            MySqlConnection conexionBD = ConnectionUtil.obtenerConexion();
            if (conexionBD != null)
            {
                try
                {
                    string sentencia = "DELETE FROM partida WHERE idPartida = @idPartida;";
                    MySqlCommand mySqlCommand = new MySqlCommand(sentencia, conexionBD);

                    mySqlCommand.Parameters.AddWithValue("@idPartida", idPartida);
                    mySqlCommand.Prepare();
                    int filasAfectadas = mySqlCommand.ExecuteNonQuery();
                    if (filasAfectadas > 0)
                    {
                        mensaje.Error = false;
                        mensaje.MensajeRespuesta = "partida elimnado con éxito";
                    }
                    else
                    {
                        mensaje.Error = true;
                        mensaje.MensajeRespuesta = "Error al eliminar la partida";
                    }

                }
                catch (Exception ex)
                {
                    mensaje.Error = true;
                    mensaje.MensajeRespuesta = "Error en el servicio: " +ex.Message;
                    conexionBD.Close();
                }
            }
            else
            {
                mensaje.Error = true;
                mensaje.MensajeRespuesta = "Por el momento no hay conexión con la BD...";
                conexionBD.Close();
            }
            conexionBD.Close();
            return mensaje;
        }

        public static Mensaje EliminarPartidas(int idUsuario)//para eliminar todas las partidas del usuario al ingresar a su cuenta
        {
            Mensaje mensaje = new Mensaje();
            MySqlConnection conexionBD = ConnectionUtil.obtenerConexion();
            if (conexionBD != null)
            {
                try
                {
                    string sentencia = "DELETE FROM partida WHERE idUsuarioUno = @idUsuario;";
                    MySqlCommand mySqlCommand = new MySqlCommand(sentencia, conexionBD);

                    mySqlCommand.Parameters.AddWithValue("@idUsuario", idUsuario);
                    mySqlCommand.Prepare();
                    int filasAfectadas = mySqlCommand.ExecuteNonQuery();
                        mensaje.Error = false;
                        mensaje.MensajeRespuesta = "partidas  residuales elimnadas con éxito";
                }
                catch (Exception ex)
                {
                    mensaje.Error = true;
                    mensaje.MensajeRespuesta = "Error en el servicio: " + ex.Message;
                    conexionBD.Close();
                }
            }
            else
            {
                mensaje.Error = true;
                mensaje.MensajeRespuesta = "Por el momento no hay conexión con la BD...";
                conexionBD.Close();
            }
            conexionBD.Close();
            return mensaje;
        }

        public static MensajeRecuperacionPartidas RecuperarPartidas()
        {
            
            List<Partida> partidasBD = new List<Partida>();
            
            MensajeRecuperacionPartidas mensajePartidasRecuperadas = new MensajeRecuperacionPartidas();

            MySqlConnection conexionBD = ConnectionUtil.obtenerConexion();
            if (conexionBD != null)
            {
                
                try
                {
                    string consulta = string.Format("select * from partida p inner join usuario u on p.idUsuarioUno = u.idUsuario where estadoPartida='En Espera';");
                    MySqlCommand mySqlCommand = new MySqlCommand(consulta, conexionBD);
                    MySqlDataReader respuestaBD = mySqlCommand.ExecuteReader();
                    while (respuestaBD.Read())
                    {

                        Partida partida = new Partida();
                        Usuario usuario = new Usuario();

                        partida.IdPartida = ((respuestaBD.IsDBNull(0)) ? 0 : respuestaBD.GetInt32(0));
                        partida.FechaCreacion = ((respuestaBD.IsDBNull(1)) ? "" : respuestaBD.GetString(1));
                        partida.EstadoPartida = (respuestaBD.IsDBNull(2) ? "" : respuestaBD.GetString(2));
                        partida.IdPalabra = ((respuestaBD.IsDBNull(3)) ? 0 : respuestaBD.GetInt32(3));
                        partida.IdUsuarioUno = ((respuestaBD.IsDBNull(4)) ? 0 : respuestaBD.GetInt32(4));
                        //espacio para agregar al usuarioDOs
                        partida.IdUsuarioUno = ((respuestaBD.IsDBNull(6)) ? 0 : respuestaBD.GetInt32(6));
                        partida.NombreCreador = ((respuestaBD.IsDBNull(7)) ? "" : respuestaBD.GetString(7));
                        partida.CorreoCreador = ((respuestaBD.IsDBNull(11)) ? "" : respuestaBD.GetString(11));

                        partidasBD.Add(partida);
                                        }
                    mensajePartidasRecuperadas.Partidas = partidasBD;
                    
                    mensajePartidasRecuperadas.Error = false;
                    mensajePartidasRecuperadas.Mensaje = "partidas y usuarios recuperados exitosamente";

                }
                catch (Exception ex)
                {
                    mensajePartidasRecuperadas.Error = true;
                    mensajePartidasRecuperadas.Mensaje = "Ocurrio un error al recuperar las partida: "+ex.Message;
                    conexionBD.Close();
                }
            }
            conexionBD.Close();
            return mensajePartidasRecuperadas;
        }

        public static Mensaje registrarUsuarioDosPartida(Usuario usuario, int idPartida)
        {
            Mensaje mensaje = new Mensaje();
            MySqlConnection conexionBD = ConnectionUtil.obtenerConexion();
            if (conexionBD != null)
            {
                try//no le paso el username
                {
                    string sentencia = "UPDATE partida SET idUsuarioDos = @idUsuarioDos,estadoPartida = @estadoPartida where idPartida = @idPartida";
                    MySqlCommand mySqlCommand = new MySqlCommand(sentencia, conexionBD);
                    mySqlCommand.Parameters.AddWithValue("@idUsuarioDos", usuario.IdUsuario);
                    mySqlCommand.Parameters.AddWithValue("@estadoPartida", "Partida en curso");
                    mySqlCommand.Parameters.AddWithValue("@idPartida", idPartida);

                    mySqlCommand.Prepare();
                    int filasAfectadas = mySqlCommand.ExecuteNonQuery();
                    if (filasAfectadas > 0)
                    {
                        mensaje.Error = false;
                        mensaje.MensajeRespuesta = "partida actualizado con éxito";
                    }
                    else
                    {
                        mensaje.Error = true;
                        mensaje.MensajeRespuesta = "Ha ocurrido un error o la aprtida seleccionada ya no existe";
                    
                    }

                }
                catch (Exception ex)
                {
                    mensaje.Error = true;
                    mensaje.MensajeRespuesta = ex.Message;
                    conexionBD.Close();
                }
            }
            else
            {
                mensaje.Error = true;
                mensaje.MensajeRespuesta = "Por el momento no hay conexión con los servicios...";
                conexionBD.Close();
            }
            conexionBD.Close();
            return mensaje;
        }

        public static Mensaje CrearPartidaEjecucion(int idPartida,int errores, int turno,string estadoPartida)//tabla que crea la partida usada en tiempo real
        {
            Mensaje mensaje = new Mensaje();
            MySqlConnection conexionBD = ConnectionUtil.obtenerConexion();
            if (conexionBD != null)
            {
                try
                {
                    string sentencia = "INSERT INTO partidaEjecucion (idPartida,cantidadErrores,turnoJugador,estadoPartidaEjecucion) " +
                                       "VALUES(@idPartida,@cantidadErrores,@turnoJugador,@estadoPartidaEjecucion)";
                    MySqlCommand mySqlCommand = new MySqlCommand(sentencia, conexionBD);
                    mySqlCommand.Parameters.AddWithValue("@idPartida", idPartida);
                    mySqlCommand.Parameters.AddWithValue("@cantidadErrores", errores);
                    mySqlCommand.Parameters.AddWithValue("@turnoJugador", turno);
                    mySqlCommand.Parameters.AddWithValue("@estadoPartidaEjecucion", estadoPartida);

                    //mySqlCommand.Parameters.AddWithValue("@idUsuarioDos", partidaCreacion.UsuarioRetador.IdUsuario);
                    mySqlCommand.Prepare();
                    int filasAfectadas = mySqlCommand.ExecuteNonQuery();
                    if (filasAfectadas > 0)
                    {
                        conexionBD.Close();
                        mensaje.Error = false;
                        mensaje.MensajeRespuesta = "Partida creada con exito";
                    }
                    else
                    {
                        conexionBD.Close();
                        mensaje.Error = true;
                        mensaje.MensajeRespuesta = "Error al crear la partida en sistema";
                    }

                }
                catch (Exception ex)
                {
                    conexionBD.Close();
                    mensaje.Error = true;
                    mensaje.MensajeRespuesta = ex.Message;
                }
            }
            else
            {
                mensaje.Error = true;
                mensaje.MensajeRespuesta = "Por el momento no hay conexión con los servicios...";
            }
            conexionBD.Close();
            return mensaje;
        }

        public static MensajePartidaEjecucion ObtenerPartidaEjecucion(int idPartida)
        {
            MensajePartidaEjecucion mensajeRecuperacion = new MensajePartidaEjecucion();
            MySqlConnection conexionBD = ConnectionUtil.obtenerConexion();
            if (conexionBD != null)
            {
                try
                {
                    string consulta = string.Format("select * from partida p inner join partidaejecucion pj on p.idPartida = pj.idPartida inner join palabras pb on p.Palabra_idPalabra1 = pb.idPalabra where p.idPartida=@idPartida;");
                    MySqlCommand mySqlCommand = new MySqlCommand(consulta, conexionBD);
                    mySqlCommand.Parameters.AddWithValue("@idPartida", idPartida);
                    MySqlDataReader respuestaBD = mySqlCommand.ExecuteReader();
                    if (respuestaBD.Read())
                    {
                        PartidaEjecucion partida =new PartidaEjecucion();
                        partida.IdPartida = ((respuestaBD.IsDBNull(0)) ? 0 : respuestaBD.GetInt32(0));
                        partida.IdUsuarioUno = ((respuestaBD.IsDBNull(4)) ? 0 : respuestaBD.GetInt32(4));
                        partida.IdUsuarioDos = ((respuestaBD.IsDBNull(5)) ? 0 : respuestaBD.GetInt32(5));
                        partida.IdPartidaEjecucion = ((respuestaBD.IsDBNull(6)) ? 0 : respuestaBD.GetInt32(6));
                        partida.CantidadErrores = ((respuestaBD.IsDBNull(8)) ? 0 : respuestaBD.GetInt32(8));
                        partida.TurnoJugador = ((respuestaBD.IsDBNull(9)) ? 0 : respuestaBD.GetInt32(9));
                        partida.LetraIngresada = ((respuestaBD.IsDBNull(10)) ? "" : respuestaBD.GetString(10));
                        partida.EstadoPartidaEjecucion = ((respuestaBD.IsDBNull(11)) ? "" : respuestaBD.GetString(11));
                        partida.idPalabra = ((respuestaBD.IsDBNull(12)) ? 0 : respuestaBD.GetInt32(12));
                        partida.Palabra = ((respuestaBD.IsDBNull(13)) ? "" : respuestaBD.GetString(13));
                        partida.DescripcionPalabra = ((respuestaBD.IsDBNull(14)) ? "" : respuestaBD.GetString(14));
                        
                        mensajeRecuperacion.Error = false;
                        mensajeRecuperacion.partidaEjecucion = partida;
                        mensajeRecuperacion.Mensaje = "Partida recuperada exitosamente";
                        //DUDA:por que marca error si le paso directamente los datos a mensajeRecuperacion.Partida, y no al pasar a una instancia aparte y despues pasarsela a mensajeRecuperacion
                        conexionBD.Close();
                    }
                }
                catch (Exception ex)
                {
                    conexionBD.Close();
                    mensajeRecuperacion.Error = true;
                    mensajeRecuperacion.Mensaje += "Ocurrio un error al recuperar la informacion de la partida en ejecucion: " + ex.Message;
                }
            }
            conexionBD.Close();
            return mensajeRecuperacion;
        }

        public static Mensaje RegistrarJugadaJugadorDos(int turnoJugador,string letra,int idPartidaEjecucion)
        {
            Mensaje mensaje = new Mensaje();
            MySqlConnection conexionBD = ConnectionUtil.obtenerConexion();
            if (conexionBD != null)
            {
                try//no le paso el username
                {
                    mensaje.MensajeRespuesta = "_";
                    string sentencia = "update partidaEjecucion set turnoJugador =@turnoJugador , letraIngresada =@letra where idPartidaEjecucion = @idPartidaEjecucion; ";
                    MySqlCommand mySqlCommand = new MySqlCommand(sentencia, conexionBD);
                    mySqlCommand.Parameters.AddWithValue("@turnoJugador", turnoJugador);
                    mySqlCommand.Parameters.AddWithValue("@letra", letra);
                    mySqlCommand.Parameters.AddWithValue("@idPartidaEjecucion", idPartidaEjecucion);
                    mensaje.MensajeRespuesta += "-";
                    mySqlCommand.Prepare();
                    int filasAfectadas = mySqlCommand.ExecuteNonQuery();
                    mensaje.MensajeRespuesta = ">";
                    if (filasAfectadas > 0)
                    {
                        mensaje.Error = false;
                        mensaje.MensajeRespuesta = "partida en ejecucion actualizado con éxito";
                        conexionBD.Close();
                    }
                    else
                    {
                        mensaje.Error = true;
                        mensaje.MensajeRespuesta = "Ha ocurrido un error al registrar la jugada";
                        conexionBD.Close();
                    }

                }
                catch (Exception ex)
                {
                    mensaje.Error = true;
                    mensaje.MensajeRespuesta += ex.Message;
                    conexionBD.Close();
                }
            }
            else
            {
                mensaje.Error = true;
                mensaje.MensajeRespuesta = "Por el momento no hay conexión con los servicios...";
                conexionBD.Close();
            }
            conexionBD.Close();
            return mensaje;
        }

        public static Mensaje RegistrarJugadaEquivocada(int turnoJugador, int cantidadErrores, int idPartidaEjecucion)
        {
            Mensaje mensaje = new Mensaje();
            MySqlConnection conexionBD = ConnectionUtil.obtenerConexion();
            if (conexionBD != null)
            {
                try//no le paso el username
                {
                    string sentencia = "update partidaejecucion set turnoJugador=@turnoJugador , cantidadErrores =@cantidadErrores  where idPartidaejecucion=@idPartidaEjecucion ;";
                    MySqlCommand mySqlCommand = new MySqlCommand(sentencia, conexionBD);
                    mySqlCommand.Parameters.AddWithValue("@turnoJugador", turnoJugador);
                    mySqlCommand.Parameters.AddWithValue("@cantidadErrores", cantidadErrores);
                    mySqlCommand.Parameters.AddWithValue("@idPartidaEjecucion", idPartidaEjecucion);

                    mySqlCommand.Prepare();
                    int filasAfectadas = mySqlCommand.ExecuteNonQuery();
                    if (filasAfectadas > 0)
                    {
                        mensaje.Error = false;
                        mensaje.MensajeRespuesta = "partida en ejecucion actualizado con éxito";
                        conexionBD.Close();
                    }
                    else
                    {
                        mensaje.Error = true;
                        mensaje.MensajeRespuesta = "Ha ocurrido un error al registrar la jugada";
                        conexionBD.Close();
                    }

                }
                catch (Exception ex)
                {
                    conexionBD.Close();
                    mensaje.Error = true;
                    mensaje.MensajeRespuesta = ex.Message;
                }
            }
            else
            {
                conexionBD.Close();
                mensaje.Error = true;
                mensaje.MensajeRespuesta = "Por el momento no hay conexión con los servicios...";
            }
            conexionBD.Close();
            return mensaje;
        }

        public static Mensaje RegistrarVictoria(int idPartidaEjecucion, string estadoPartida,int turnoJugador)
        {
            Mensaje mensaje = new Mensaje();
            MySqlConnection conexionBD = ConnectionUtil.obtenerConexion();
            if (conexionBD != null)
            {
                try//no le paso el username
                {
                    string sentencia = "update partidaejecucion set estadoPartidaEjecucion=@estadoPartida, turnoJugador=@turnojugador where idPartidaEjecucion=@idPartidaEjecucion ;";
                    MySqlCommand mySqlCommand = new MySqlCommand(sentencia, conexionBD);
                    mySqlCommand.Parameters.AddWithValue("@estadoPartida", estadoPartida);
                    mySqlCommand.Parameters.AddWithValue("@idPartidaEjecucion", idPartidaEjecucion);
                    mySqlCommand.Parameters.AddWithValue("@turnoJugador", turnoJugador);
                    mySqlCommand.Prepare();
                    int filasAfectadas = mySqlCommand.ExecuteNonQuery();
                    if (filasAfectadas > 0)
                    {
                        conexionBD.Close();
                        mensaje.Error = false;
                        mensaje.MensajeRespuesta = "victoria actualizada con éxito";
                    }
                    else
                    {
                        conexionBD.Close();
                        mensaje.Error = true;
                        mensaje.MensajeRespuesta = "Ha ocurrido un error al registrar la victoria";
                    }

                }
                catch (Exception ex)
                {
                    conexionBD.Close();
                    mensaje.Error = true;
                    mensaje.MensajeRespuesta = ex.Message;
                }
            }
            else
            {
                conexionBD.Close();
                mensaje.Error = true;
                mensaje.MensajeRespuesta = "Por el momento no hay conexión con los servicios...";
            }
            conexionBD.Close();
            return mensaje;
        }

        public static Mensaje FinalizarPartida(int idPartida, string estadoPartida)
        {
            Mensaje mensaje = new Mensaje();
            MySqlConnection conexionBD = ConnectionUtil.obtenerConexion();
            if (conexionBD != null)
            {
                try//no le paso el username
                {
                    string sentencia = "update partida set estadoPartida=@estadoPartida where idPartida=@idPartida ;";
                    MySqlCommand mySqlCommand = new MySqlCommand(sentencia, conexionBD);
                    mySqlCommand.Parameters.AddWithValue("@estadoPartida", estadoPartida);
                    mySqlCommand.Parameters.AddWithValue("@idPartida", idPartida);
                    mySqlCommand.Prepare();
                    int filasAfectadas = mySqlCommand.ExecuteNonQuery();
                    if (filasAfectadas > 0)
                    {
                        conexionBD.Close();
                        mensaje.Error = false;
                        mensaje.MensajeRespuesta = "Partida marcada como finalizada con éxito";
                    }
                    else
                    {
                        conexionBD.Close();
                        mensaje.Error = true;
                        mensaje.MensajeRespuesta = "Ha ocurrido un error al marcar el fin de la partida";
                    }

                }
                catch (Exception ex)
                {
                    conexionBD.Close();
                    mensaje.Error = true;
                    mensaje.MensajeRespuesta = ex.Message;
                }
            }
            else
            {
                conexionBD.Close();
                mensaje.Error = true;
                mensaje.MensajeRespuesta = "Por el momento no hay conexión con los servicios...";
            }
            conexionBD.Close();
            return mensaje;
        }

        public static Mensaje RegistrarVictoriaHistorial(int puntaje, int idPartida)
        {
            Mensaje mensaje = new Mensaje();
            MySqlConnection conexionBD = ConnectionUtil.obtenerConexion();
            if (conexionBD != null)
            {
                try
                {
                    string sentencia = "INSERT INTO historialpartidas (puntaje,idPartida) " +
                                       "VALUES(@puntaje,@idPartida)";
                    MySqlCommand mySqlCommand = new MySqlCommand(sentencia, conexionBD);
                    mySqlCommand.Parameters.AddWithValue("@puntaje", puntaje);
                    mySqlCommand.Parameters.AddWithValue("@idPartida", idPartida);
                   
                    mySqlCommand.Prepare();
                    int filasAfectadas = mySqlCommand.ExecuteNonQuery();
                    if (filasAfectadas > 0)
                    {
                        conexionBD.Close();
                        mensaje.Error = false;
                        mensaje.MensajeRespuesta = "Victoria registrada en el historial del jugador";
                    }
                    else
                    {
                        conexionBD.Close();
                        mensaje.Error = true;
                        mensaje.MensajeRespuesta = "Error al registrar la victoria en el historial";
                    }

                }
                catch (Exception ex)
                {
                    conexionBD.Close();
                    mensaje.Error = true;
                    mensaje.MensajeRespuesta = ex.Message;
                }
            }
            else
            {
                conexionBD.Close();
                mensaje.Error = true;
                mensaje.MensajeRespuesta = "Por el momento no hay conexión con los servicios...";
            }
            conexionBD.Close();
            return mensaje;
        }

        public static MensajeHistorialPartida ObtenerHistorialVictorias(int idUsuario)
        {
            MensajeHistorialPartida mensajeRecuperacion = new MensajeHistorialPartida();
            MySqlConnection conexionBD = ConnectionUtil.obtenerConexion();
            List<HistorialPartida> lista = new List<HistorialPartida>();
            if (conexionBD != null)
            {
                try
                {
                    string consulta = string.Format("select p.fechaCreacion, u.nombreCompleto,u.correo, hp.puntaje, p.idUsuarioUno from partida p inner join partidaejecucion pe on pe.idPartida = p.idPartida inner join usuario u on u.idUsuario = p.idUsuarioDos inner join historialpartidas hp on hp.idPartida = p.idPartida  where pe.estadoPartidaEjecucion=@estadoPartidaEjecucion and p.idUsuarioDos=@idUsuario;");
                    MySqlCommand mySqlCommand = new MySqlCommand(consulta, conexionBD);
                    mySqlCommand.Parameters.AddWithValue("@estadoPartidaEjecucion", "victoria");
                    mySqlCommand.Parameters.AddWithValue("@idUsuario", idUsuario);
                    MySqlDataReader respuestaBD = mySqlCommand.ExecuteReader();
                    while (respuestaBD.Read())
                    {
                        HistorialPartida historial = new HistorialPartida();
                        historial.FechaPartida = ((respuestaBD.IsDBNull(0)) ? "" : respuestaBD.GetString(0));
                        historial.NombrePerdedor = ((respuestaBD.IsDBNull(1)) ? "" : respuestaBD.GetString(1));
                        historial.CorreoPerdedor = ((respuestaBD.IsDBNull(2)) ? "" : respuestaBD.GetString(2));
                       
                        historial.Puntaje = ((respuestaBD.IsDBNull(3)) ? 0 : respuestaBD.GetInt32(3));
                        historial.IdUsuarioPerdedor = ((respuestaBD.IsDBNull(4)) ? 0 : respuestaBD.GetInt32(4));
                        lista.Add(historial);
                        
                    }
                    mensajeRecuperacion.Error = false;
                    mensajeRecuperacion.PartidasRecuperadas = lista;
                    mensajeRecuperacion.MensajeRecuperacionhistorial = "Historial de partidas recuperadas exitosamente";
                }
                catch (Exception ex)
                {
                    conexionBD.Close();
                    mensajeRecuperacion.Error = true;
                    mensajeRecuperacion.MensajeRecuperacionhistorial =  ex.Message;
                }
            }
            conexionBD.Close();
            return mensajeRecuperacion;
        }

        public static Mensaje CancelarPartidaEjecucion(int idPartidaEjecucion, string estadoPartida, int turnoJugador)
        {
            Mensaje mensaje = new Mensaje();
            MySqlConnection conexionBD = ConnectionUtil.obtenerConexion();
            if (conexionBD != null)
            {
                try
                {
                    string sentencia = "update partidaejecucion set estadoPartidaEjecucion=@estadoPartida, turnoJugador=@turnojugador where idPartidaEjecucion=@idPartidaEjecucion ;";
                    MySqlCommand mySqlCommand = new MySqlCommand(sentencia, conexionBD);
                    mySqlCommand.Parameters.AddWithValue("@estadoPartida", estadoPartida);
                    mySqlCommand.Parameters.AddWithValue("@idPartidaEjecucion", idPartidaEjecucion);
                    mySqlCommand.Parameters.AddWithValue("@turnoJugador", turnoJugador);
                    mySqlCommand.Prepare();
                    int filasAfectadas = mySqlCommand.ExecuteNonQuery();
                    if (filasAfectadas > 0)
                    {
                        conexionBD.Close();
                        mensaje.Error = false;
                        mensaje.MensajeRespuesta = "Partida cancelada con exito";
                    }
                    else
                    {
                        conexionBD.Close();
                        mensaje.Error = true;
                        mensaje.MensajeRespuesta = "Ha ocurrido un error al cancelar la partida";
                    }

                }
                catch (Exception ex)
                {
                    conexionBD.Close();
                    mensaje.Error = true;
                    mensaje.MensajeRespuesta = ex.Message;
                }
            }
            else
            {
                conexionBD.Close();
                mensaje.Error = true;
                mensaje.MensajeRespuesta = "Por el momento no hay conexión con los servicios...";
            }
            conexionBD.Close();
            return mensaje;
        }

    }//class
}//namespace