﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace ServicioWCF.Modelo.Poco
{
    public class Partida
    {
        public int IdPartida { get; set; }
        public string FechaCreacion { get; set; }
        public string EstadoPartida { get; set; }

        public int IdUsuarioUno { get; set; }
       // public Usuario UsuarioCreador { get; set; }
       
        public int IdUsuarioDos { get; set; }
       // public Usuario UsuarioRetador { get; set; }
        public int IdPalabra { get; set; }
       //public Palabra palabraSeleccionada { get; set; }

        ////////////////////////////
        public string CorreoCreador { get; set; }
        public string NombreCreador { get; set; }
    }
}