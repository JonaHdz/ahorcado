﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace ServicioWCF.Modelo.Poco
{
    public class MensajePartidaEjecucion
    {
        public PartidaEjecucion partidaEjecucion { get; set; }
        public Boolean Error { get; set; }
        public string Mensaje { get; set; }
    }
}