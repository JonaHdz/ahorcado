﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace ServicioWCF.Modelo.Poco
{
    public class HistorialPartida
    {

        public string FechaPartida { get; set; }
        public string CorreoPerdedor { get; set; }

        public string NombrePerdedor { get; set; }

        public int Puntaje { get; set; }

        public int IdUsuarioPerdedor { get; set; }
    }
}