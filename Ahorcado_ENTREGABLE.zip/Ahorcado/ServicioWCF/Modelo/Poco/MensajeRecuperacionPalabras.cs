﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace ServicioWCF.Modelo.Poco
{
    public class MensajeRecuperacionPalabras
    {
       public Boolean Error { get; set; }
        public List<Palabra> Palabras { get; set; }
        public string Mensaje { get; set; }
    }
}