﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace ServicioWCF.Modelo.Poco
{
    public class MensajeHistorialPartida
    {
        public List<HistorialPartida> PartidasRecuperadas { get; set; }
        public Boolean Error { get; set; }
        public string MensajeRecuperacionhistorial { get; set; }
    }
}