﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace ServicioWCF.Modelo.Poco
{
    public class PartidaEjecucion
    {
        public int IdPartida { get; set; }
        public int IdUsuarioUno { get; set; }
        public int IdUsuarioDos { get; set; }
        public int IdPartidaEjecucion { get; set; }
        public int CantidadErrores { get; set; }
        public int TurnoJugador { get; set; }
        public int idPalabra { get; set; }
        public string Palabra { get; set; }
        public string DescripcionPalabra { get; set; }

        public string LetraIngresada { get; set; }
        public string EstadoPartidaEjecucion { get; set; }

    }
}