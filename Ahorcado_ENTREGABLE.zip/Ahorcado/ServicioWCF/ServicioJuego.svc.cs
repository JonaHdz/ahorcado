﻿using ServicioWCF.Modelo.Dao;
using ServicioWCF.Modelo.Poco;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Runtime.Serialization;
using System.ServiceModel;
using System.Text;

namespace ServicioWCF
{
    // NOTA: puede usar el comando "Rename" del menú "Refactorizar" para cambiar el nombre de clase "ServicioJuego" en el código, en svc y en el archivo de configuración a la vez.
    // NOTA: para iniciar el Cliente de prueba WCF para probar este servicio, seleccione ServicioJuego.svc o ServicioJuego.svc.cs en el Explorador de soluciones e inicie la depuración.
    public class ServicioJuego : IServicioJuego
    {
        public RespuestaLogin ValidarUsuario(string correo, string password)
        {
            RespuestaLogin login = UsuarioDao.verificarUsuario(correo, password);
            return login;
        }

        public Mensaje RegistrarUsuario(Usuario usuario)//agregar la comprobacion si estan vacios, lo mismo en el emtodo para actualizar
        {
            RespuestaLogin correoRecuperado = new RespuestaLogin();
            Mensaje registro = new Mensaje();
            if (!usuario.NombreCompleto.Equals("") && !usuario.Correo.Equals("") && !usuario.Telefono.Equals("") && !usuario.Password.Equals(""))
            {

                if (usuario.Telefono.All(char.IsDigit))
                {
                    try
                    {
                        DateTime.Parse(usuario.FechaNacimiento);
                        correoRecuperado = UsuarioDao.RecuperarCorreo(usuario.Correo);
                        if (correoRecuperado.UsuarioCorrecto)
                        {
                            registro = UsuarioDao.insertarUsuario(usuario);
                        }

                        else
                        {
                            registro.Error = true;
                            registro.MensajeRespuesta = correoRecuperado.Mensaje;
                        }

                    }
                    catch (Exception ex)
                    {
                        registro.Error = true;
                        registro.MensajeRespuesta = "El formato de fecha no es valido o no fue llenado. Favor de verificar";
                        return registro;
                    }


                }
                else
                {
                    registro.Error = true;
                    registro.MensajeRespuesta = "El numero de telefono no es valido, favor de verificar";
                }
            }
            else
            {
                registro.Error = true;
                registro.MensajeRespuesta = "Campos obligatorios. favor de verificar";
            }

            return registro;
        }

        public RespuestaLogin ActualizarUsuario(Usuario usuario)
        {
            RespuestaLogin registro = new RespuestaLogin();
            if (!usuario.NombreCompleto.Equals("") && !usuario.Correo.Equals("") && !usuario.Telefono.Equals("") && !usuario.Password.Equals(""))
            {

                if (usuario.Telefono.All(char.IsDigit))
                {
                    try
                    {
                        DateTime.Parse(usuario.FechaNacimiento);
                        registro = UsuarioDao.ActualizarUsuario(usuario);
                    }
                    catch (Exception ex)
                    {
                        registro.UsuarioCorrecto = true;
                        registro.Mensaje = "El formato de fecha no es valido o no fue llenado. Favor de verificar";
                        return registro;
                    }


                }
                else
                {
                    registro.UsuarioCorrecto = true;
                    registro.Mensaje = "El numero de telefono no es valido, favor de verificar";
                }
            }
            else
            {
                registro.UsuarioCorrecto = true;
                registro.Mensaje = "Campos obligatorios. favor de verificar";
            }

            return registro;

            //RespuestaLogin respuesta = UsuarioDao.ActualizarUsuario(usuario);
            //return respuesta;
        }

        public MensajeRecuperacionPalabras RecuperarPalabras()
        {
            MensajeRecuperacionPalabras mensaje = PalabraDao.ObtenerPalabras();
            return mensaje;
        }

        public Mensaje CrearPartida(Partida partida)
        {
            Mensaje mensaje = PartidaDao.RegistrarpartidaNueva(partida);
            return mensaje;
        }

        public MensajePartida RecuperaInfoPartida(int idUsuarioUno)
        {
            MensajePartida partida = PartidaDao.ObtenerPartida(idUsuarioUno);
            return partida;
        }

        public Mensaje EliminarPartida(int idPartida)
        {
            Mensaje mensaje = PartidaDao.EliminarPartida(idPartida);
            return mensaje;
        }

        public MensajeRecuperacionPartidas recuperarPartidas()
        {
            MensajeRecuperacionPartidas partidasRecuperadas = PartidaDao.RecuperarPartidas();
            return partidasRecuperadas;
        }

        public Mensaje RegistrarUsuarioDos(Usuario usuario, int idPartida)
        {
            Mensaje mensaje = PartidaDao.registrarUsuarioDosPartida(usuario, idPartida);
            return mensaje;
        }

        public MensajePartida EsperaJugadorUno(int idUsuarioUno)//el jugador uno espera hasta que el dos le mande una señal
        {
            MensajePartida partidaRecuperada = PartidaDao.ObtenerPartida(idUsuarioUno);
            return partidaRecuperada;

        }

        public Mensaje EliminarPartidasResiduales(int idUsuario)
        {
            Mensaje mensaje = PartidaDao.EliminarPartidas(idUsuario);
            return mensaje;
        }

        public RespuestaLogin RecuperarInformacionUsuario(int idUsuario)
        {
            RespuestaLogin respuesta = UsuarioDao.RecuperarInformacionUsuario(idUsuario);
            return respuesta;
        }

        public Mensaje CrearPArtidaEjecucion(int idPartida, int errores, int turnoJugador)
        {
            Mensaje mensaje = PartidaDao.CrearPartidaEjecucion(idPartida, errores, turnoJugador, "ejecucion");
            return mensaje;
        }

        public MensajePartidaEjecucion recuperarPartidaEjecucion(int idPartida)
        {
            MensajePartidaEjecucion partidaEjecucion = PartidaDao.ObtenerPartidaEjecucion(idPartida);
            return partidaEjecucion;
        }

        public Mensaje RegistrarJugadaJugadorDos(int turnoJugador, string letra, int idPartidaEjecucion)
        {
            Mensaje mensaje = PartidaDao.RegistrarJugadaJugadorDos(turnoJugador, letra, idPartidaEjecucion);
            return mensaje;
        }

        public Mensaje RegistrarJugadaEquivocada(int turnoJugador, int cantidadErrores, int idpartidaEjecucion)
        {
            Mensaje mensaje = PartidaDao.RegistrarJugadaEquivocada(turnoJugador, cantidadErrores, idpartidaEjecucion);
            return mensaje;
        }



        public Mensaje RegistrarFinPartidaEjecucion(int idPartidaEjecucion, bool estadoganador)
        {
            Mensaje respuesta;
            if (estadoganador)
                respuesta = PartidaDao.RegistrarVictoria(idPartidaEjecucion, "victoria", 2);
            else
                respuesta = PartidaDao.RegistrarVictoria(idPartidaEjecucion, "derrota", 2);
            return respuesta;
        }

        public Mensaje RegistrarFinPartida(int idPartida)
        {
            Mensaje respuesta = PartidaDao.FinalizarPartida(idPartida, "Finalizada");
            return respuesta;
        }

        public Mensaje RegistrarVictoriaHistorial(int idPartida)
        {
            Mensaje respuesta = PartidaDao.RegistrarVictoriaHistorial(10, idPartida);
            return respuesta;
        }

        public MensajePartida RecuperarPartidaEspera(int idUsuario)//este metodo lo puedo borrar porque no lo utilice
        {
            MensajePartida respuesta = PartidaDao.ObtenerPartidaEspera(idUsuario);
            return respuesta;

        }

        public MensajeHistorialPartida RecuperarHistorialpartidas(int idUsuario)
        {
            MensajeHistorialPartida historial = new MensajeHistorialPartida();
            RespuestaLogin usuarioRecuperado = new RespuestaLogin();
            historial = PartidaDao.ObtenerHistorialVictorias(idUsuario);
            int contador = historial.PartidasRecuperadas.Count();
            if(!historial.Error)
            {
                for(int i = 0; i < contador; i++)
                {
                    HistorialPartida historialAuxiliar =new HistorialPartida();
                    historialAuxiliar = historial.PartidasRecuperadas[i];
                    usuarioRecuperado = UsuarioDao.RecuperarInformacionUsuario(historialAuxiliar.IdUsuarioPerdedor);
                    historial.PartidasRecuperadas[i].CorreoPerdedor = usuarioRecuperado.InformacionUsuario.Correo;
                    historial.PartidasRecuperadas[i].NombrePerdedor = usuarioRecuperado.InformacionUsuario.NombreCompleto;

                }

            }
            return historial;
        }

        public Mensaje CancelarPartidaEjecucion(int idPartidaEjecucion, int turnoJugador,int idPartida)
        {
            Mensaje respuestaCancelacionPartidaEjecucion = PartidaDao.CancelarPartidaEjecucion(idPartidaEjecucion, "cancelada", turnoJugador);
            Mensaje respuestaCancelacionPartida;
            Mensaje respuesta = new Mensaje();
            if (!respuestaCancelacionPartidaEjecucion.Error)
            {
                respuestaCancelacionPartida = RegistrarFinPartida(idPartida);
                if(!respuestaCancelacionPartida.Error)
                {
                    
                    respuesta.Error = false;
                    respuesta.MensajeRespuesta = "Se realizo todo el proceso de cancelación exitosamente";
                }
                else
                {
                    respuesta.Error = true;
                    respuesta.MensajeRespuesta = "Ocurrio un problema al cancelar la partida ";

                }
            }
            else
            {
                respuesta.Error = true;
                respuesta.MensajeRespuesta = "Ocurrio un problema al cancelar la partida";
            }
            return respuesta;
        }
    }
}
